<!-- Main content -->
<?php

$response=array('action'=>"", 'message'=>"");

if(isset($_POST['btn_save'])){
   
    
    $date = explode('-',$_POST['daterange']);
    $tmp = explode("/",trim($date[0]));
    $tmp1 = $tmp[2]."-".$tmp[0]."-".$tmp[1];
    //echo $tmp1;

    $tmp_ = explode("/",trim($date[1]));
    $tmp2 = $tmp_[2]."-".$tmp_[0]."-".$tmp_[1];
    
   

    $data = array('model'=>"leave",'keys'=>"employee_id, datefrom, dateto, leavetype_id, status, paidstate");
    $lt = $app->getLeavetypes();
    $st = $lt[$_POST['leavetype_id']]['status'];
    //echo $st;

    if(isset($_POST['id'])){
        $data['values']="employee_id = '".$_POST['employee_id']."', datefrom = '".$tmp1."', dateto = '".$tmp2."', leavetype_id = '".$_POST['leavetype_id']."', reason = '".$_POST['reason']."', paidstate = '".$st."'";
        $data['condition'] = " WHERE id = '".$_POST['id']."'";
        $response = $app->update2($data);
    }else{
        $date = date("Y")."-".date("m")."-".date("d");

        $data2 = array(
            'model'=>'leave',
            'keys'=>"employee_id, datefrom, dateto, leavetype_id, status, reason, paidstate",
            'values'=>"'".$_SESSION['login_id']."', '".$tmp1."', '".$tmp2."', '".$_POST['leavetype_id']."', 'filed', '".$_POST['reason']."', '".$st."'"
        );
        $response = $app->create2($data2);
        $response['message'] = "Successful";
      
    }

}
//$rvalue =array();
if(isset($_GET['id'])){
    $action = "Update";
    $rqdata = array("model"=>"leave", "condition"=>" WHERE id = '".$_GET['id']."'");
    $department = $app->getRecord2($rqdata);
    $rvalue = $department['data'][0];
    //$rvalue['employee_id'] = json_decode($rvalue['employee_id']);
    //echo json_encode($rvalue);

}else{ $action = "Create"; }

$emps = $app->getEmployees();
$leavetypes = $app->getLeavetypes();
$module = explode("-",$page);

?>
<section class="content" >


    <div class="row">
        <div class="col-xs-12">

            <?php

            if($response['message']=="Successful"){

                echo '<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-check"></i> Alert!</h4>
                Record Saved Successfully!
              </div>';
            }


            ?>


        </div>
        <div class="col-xs-12">
            <form name="user" method="post" >
                <div class="modal-content">
                    <div class="modal-header">
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                        <h4 class="modal-title" id="myModalLabel"><?php echo $action." ".ucfirst($module[0]); ?> </h4>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-8">
                                <div class="form-group" style="margin-bottom: 0px; ">

                                    <?php if(isset($_GET['id'])): ?>
                                        <input type="hidden" class="form-control" name="id" value="<?php echo $_GET['id']; ?>" required />
                                        <input type="hidden" class="form-control" name="employee_id" value="<?php echo $rvalue['employee_id']; ?>" required /> 
                                    <?php endif; ?>
                                </div>

                                


                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Reason</label>
                                    <textarea class="form-control" placeholder="Reason" name="reason" required><?php if(isset($_GET['id'])){ echo $rvalue['reason']; } ?></textarea>
                                </div>

                                <div class="form-group">
                                <label>Type Of Leave</label>
                                    <select class="form-control select2 select2-hidden-accessible" multiple="" data-placeholder="Select a Leave" name="leavetype_id" style="width: 100%;" tabindex="-1" aria-hidden="true" required>
                                        <?php
                                         foreach ($leavetypes as $key => $value) {
                                              $act="";
                                             if(isset($_GET['id']) && $key == $rvalue['leavetype_id']){  $act="selected";}
                                             echo "<option value='".$key."' ".$act.">".$value['name']."</option>";
                                         }
                                        ?>
                                    </select>   
                                </div>  
                                <label>Date(s)</label>
                                    <input name="daterange" type="text" class="form-control pull-right" id="reservation"
                                    <?php if(isset($_GET['id'])){
                                        echo $rvalue['datefrom']." - ".$rvalue['dateto'];
                                        } ?>    
                                     required=""> 
                                </div> 


                                  

                            </div>
                            <div class="col-sm-2"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="btn_save" class="btn btn-success fa fa-plus-square btn-sm" value="<?php echo $action; ?>">
                    </div>
                </div>
            </form>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->


