<!-- Main content -->
<?php

$response=array('action'=>"", 'message'=>"");

if(isset($_POST['btn_save'])){
   
    
    $date = explode('-',$_POST['daterange']);
    $tmp = explode("/",trim($date[0]));
    $tmp1 = $tmp[2]."-".$tmp[0]."-".$tmp[1];
    //echo $tmp1;

    $tmp_ = explode("/",trim($date[1]));
    $tmp2 = $tmp_[2]."-".$tmp_[0]."-".$tmp_[1];
    
   

    $data = array('model'=>"payroll",'keys'=>"payroll_code, datefrom, dateto");

    if(isset($_POST['id'])){
        $data['values']="payroll_code = '".$_POST['payroll_code']."', datefrom = '".$tmp1."', dateto = '".$tmp2."'";
        $data['condition'] = " WHERE id = '".$_POST['id']."'";
        $response = $app->update2($data);
        //echo json_encode($response);
        echo "<script>location.href='index.php?page=payroll-view&id=".$_POST['id']."';</script>";
    }else{
        $date = date("Y")."-".date("m")."-".date("d");

        $data2 = array(
            'model'=>'payroll',
            'keys'=>"payroll_code, datefrom, dateto",
            'values'=>"'".$_POST['payroll_code']."', '".$tmp1."', '".$tmp2."'"
        );
        $response = $app->create2($data2);
        $emps = $app->getEmployees();
        
        
            
        if($_POST['auto_payslip']==1):
        
        foreach($emps as $eks => $evs){
            $datehired = strtotime($evs['date_hired']);
            $payrollUpto = strtotime($tmp2);
            if($evs['auto_payslip']==1 && $datehired<$payrollUpto){
                /*if(INCLUDEONLY==""){
                    $bi = $evs['monthly']/2;
                    $datac = array("model"=>"payrollinclusive",
                                   "keys"=>"payroll_id, employee_id, deduction, incentives, total, monthly",
                                   "values"=>"'".$response['id']."', '".$evs['id']."', '0', '0', '".$bi."', '".$evs['monthly']."' ");
                    $pcreate = $app->create2($datac);
                    // (AUTO GENERATED UPON CREATION OF PAYROLL - JUST A TEST BY MAVERICK - LEAD DEVELOPER)
                    $email_message="";
                    $email_subject = " HR Management & Payroll System - Payslip";
                    $name = $evs['fname']." ".$evs['lname'];
                    $email_message .= '<html>';
                    $email_message .= '<head><meta name="viewport" content="width=device-width" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
                    $email_message .= '<style>';
                    $email_message .='* {margin: 0;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;box-sizing: border-box;font-size: 14px;}img {max-width: 100%;}';
                    $email_message .='body {background-color: #f6f6f6;}'; 
                    $email_message .= 'table td {vertical-align: top;}.body-wrap {background-color: #f6f6f6; width: 100%;}.container {display: block !important;max-width: 600px !important;margin: 0 auto !important;clear: both !important;}';
                    $email_message .= '.content {max-width: 600px; margin: 0 auto;display: block; padding: 20px;}';
                    $email_message .= '.main {background-color: #fff;border: 1px solid #e9e9e9;border-radius: 3px;}.content-wrap { padding: 20px;}.content-block {padding: 0 0 20px;}';
                    $email_message .= '.header {width: 100%;margin-bottom: 20px;}.footer { width: 100%;clear: both;color: #999;padding: 20px;}.footer p, .footer a, .footer td {color: #999; font-size: 12px;}';
                    $email_message .= 'a {color: #348eda;text-decoration: underline;}';
                    $email_message .= '.btn-primary { text-decoration: none;color: #FFF;background-color: #348eda;border: solid #348eda; border-width: 10px 20px;line-height: 2em;font-weight: bold;text-align: center;cursor: pointer;display: inline-block;border-radius: 5px;text-transform: capitalize;}';
                
                    $email_message .= '</style>';
                    $email_message .= '<title></title></head>';
                    $email_message .= '<body itemscope itemtype="http://schema.org/EmailMessage" style="width: 100% !important; height: 100%; line-height: 1.6em;"><table class="body-wrap">';
                   
                    
                    $email_message .= '<tr><td></td>';
                    
                    $email_message .= "<td class='container' width='600'><div class='content'><table class='main' width='100%' cellpadding='0' cellspacing='0'>";
                    $email_message .= "<tr><td class='alert alert-warning'></td></tr><tr>";
                    $email_message .= '<td class="content-wrap"><table width="100%" cellpadding="0" cellspacing="0">';
                    
                    $email_message .= "<tr><td><strong>Name: </strong> " . strip_tags($name) . "</td></tr>";
                	$email_message .= "<tr><td><strong>Payroll Code:  </strong> " . $_POST['payroll_code'] . " </td></tr>";
                	$email_message .= "<tr><td><strong>Inclusive Dates: </strong>" . date("M jS, Y", strtotime($tmp1))." to ".date("M jS, Y", strtotime($tmp2)) . "</td></tr>";
                	$email_message .= "<tr><td><strong>Basic:  </strong> " . $evs['monthly'] . " </td></tr>";
                	$email_message .= "<tr><td><strong>Bi-monthly:  </strong> " . $bi . " </td></tr>";
                	$email_message .= "<tr><td><strong>Incentives:  </strong> 0 </td></tr>";
                	$email_message .= "<tr><td><strong>Deductions:  </strong> 0 </td></tr>";
                	$email_message .= "<tr><td><strong>Net Pay:  </strong> " . $bi. " </td></tr>";
                	$email_message .= "<tr><td><strong>Note(s):  </strong>  </td></tr>";
                	$email_message .= "<tr><td class='content-block'><a href='http://hr.backoffice-services.net/?page=profile' class='btn-primary'>Click here</a></td></tr>";
                    $email_message .= '<tr><td class="content-block">'.EMAILFOOTER.'</td></tr></table></td></tr>';
                	
                	$email_message .= '	</td><td></td></tr></table>';	
                
                	$email_message .= "</body></html>";
                    
                    $headers  = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    $headers .= "From: ".EMAILSENDER." \r\n".
                        "Reply-To: ".NOREPLY." \r\n" ;
                    @mail($evs['email'], $email_subject, $email_message, $headers);
                }else{
                */
                 //   if(strtoupper($evs['country'])==INCLUDEONLY){
                 
                    $df = date('Y-m-d', strtotime($tmp1));
                    $dt = date('Y-m-d', strtotime($tmp2));
                    $salary = $app->getMySalary($_GET['eid'], $dt);
                    if(sizeOf($salary)>0){
                        $evs['monthly'] = $salary[0]['monthly'];
                    }
    
                    
                    
                    $bi = $evs['monthly']/2;
                    $datac = array("model"=>"payrollinclusive",
                                   "keys"=>"payroll_id, employee_id, deduction, incentives, total, monthly",
                                   "values"=>"'".$response['id']."', '".$evs['id']."', '0', '0', '".$bi."', '".$evs['monthly']."' ");
                    $pcreate = $app->create2($datac);
                    // (AUTO GENERATED UPON CREATION OF PAYROLL - JUST A TEST BY MAVERICK - LEAD DEVELOPER)
                    $email_message="";
                    $email_subject = " HR Management & Payroll System - Payslip";
                    $name = $evs['fname']." ".$evs['lname'];
                    $email_message .= '<html>';
                    $email_message .= '<head><meta name="viewport" content="width=device-width" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
                    $email_message .= '<style>';
                    $email_message .='* {margin: 0;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;box-sizing: border-box;font-size: 14px;}img {max-width: 100%;}';
                    $email_message .='body {background-color: #f6f6f6;}'; 
                    $email_message .= 'table td {vertical-align: top;}.body-wrap {background-color: #f6f6f6; width: 100%;}.container {display: block !important;max-width: 600px !important;margin: 0 auto !important;clear: both !important;}';
                    $email_message .= '.content {max-width: 600px; margin: 0 auto;display: block; padding: 20px;}';
                    $email_message .= '.main {background-color: #fff;border: 1px solid #e9e9e9;border-radius: 3px;}.content-wrap { padding: 20px;}.content-block {padding: 0 0 20px;}';
                    $email_message .= '.header {width: 100%;margin-bottom: 20px;}.footer { width: 100%;clear: both;color: #999;padding: 20px;}.footer p, .footer a, .footer td {color: #999; font-size: 12px;}';
                    $email_message .= 'a {color: #348eda;text-decoration: underline;}';
                    $email_message .= '.btn-primary { text-decoration: none;color: #FFF;background-color: #348eda;border: solid #348eda; border-width: 10px 20px;line-height: 2em;font-weight: bold;text-align: center;cursor: pointer;display: inline-block;border-radius: 5px;text-transform: capitalize;}';
                
                    $email_message .= '</style>';
                    $email_message .= '<title></title></head>';
                    $email_message .= '<body itemscope itemtype="http://schema.org/EmailMessage" style="width: 100% !important; height: 100%; line-height: 1.6em;"><table class="body-wrap">';
                   
                    
                    $email_message .= '<tr><td></td>';
                    
                    $email_message .= "<td class='container' width='600'><div class='content'><table class='main' width='100%' cellpadding='0' cellspacing='0'>";
                    $email_message .= "<tr><td class='alert alert-warning'></td></tr><tr>";
                    $email_message .= '<td class="content-wrap"><table width="100%" cellpadding="0" cellspacing="0">';
                    
                    $email_message .= "<tr><td><strong>Name: </strong> " . strip_tags($name) . "</td></tr>";
                	$email_message .= "<tr><td><strong>Payroll Code:  </strong> " . $_POST['payroll_code'] . " </td></tr>";
                	$email_message .= "<tr><td><strong>Inclusive Dates: </strong>" . date("M jS, Y", strtotime($tmp1))." to ".date("M jS, Y", strtotime($tmp2)) . "</td></tr>";
                	$email_message .= "<tr><td><strong>Basic:  </strong> " . $evs['monthly'] . " </td></tr>";
                	$email_message .= "<tr><td><strong>Bi-monthly:  </strong> " . $bi . " </td></tr>";
                	$email_message .= "<tr><td><strong>Incentives:  </strong> 0 </td></tr>";
                	$email_message .= "<tr><td><strong>Deductions:  </strong> 0 </td></tr>";
                	$email_message .= "<tr><td><strong>Net Pay:  </strong> " . $bi. " </td></tr>";
                	$email_message .= "<tr><td><strong>Note(s):  </strong>  </td></tr>";
                	$email_message .= "<tr><td class='content-block'><a href='http://hr.backoffice-services.net/?page=profile' class='btn-primary'>Click here</a></td></tr>";
                    $email_message .= '<tr><td class="content-block">'.EMAILFOOTER.'</td></tr></table></td></tr>';
                	
                	$email_message .= '	</td><td></td></tr></table>';	
                
                	$email_message .= "</body></html>";
                    if($evs['email_notify']==1){
                    $headers  = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    $headers .= "From: ".EMAILSENDER." \r\n".
                        "Reply-To: ".NOREPLY." \r\n" ;
                    @mail($evs['email'], $email_subject, $email_message, $headers);
                    }
                   // }
               // }   
            }
        }
        endif;
        
        echo "<script>location.href='index.php?page=payroll-view&id=".$response['id']."';</script>";
        $response['message'] = "Successful";

      
    }

}
//$rvalue =array();
if(isset($_GET['id'])){
    $action = "Update";
    $rqdata = array("model"=>"payroll", "condition"=>" WHERE id = '".$_GET['id']."'");
    $department = $app->getRecord2($rqdata);
    $rvalue = $department['data'][0];
    //$rvalue['employee_id'] = json_decode($rvalue['employee_id']);
    //echo json_encode($rvalue);

}else{ $action = "Create"; }

$emps = $app->getEmployees();
$leavetypes = $app->getLeavetypes();
$module = explode("-",$page);
$payrollCount = $app->getPayrollCount();
$payrollCount = $payrollCount + 1;

$len = strlen($payrollCount);
if($len==1){ $np = "00000".$payrollCount; }
elseif($len==2){ $np = "0000".$payrollCount; }
elseif($len==3){ $np = "000".$payrollCount; }
elseif($len==4){ $np = "00".$payrollCount; }
elseif($len==5){ $np = "0".$payrollCount; }
elseif($len==5){ $np = "0".$payrollCount; }
else{ $np = $payrollCount; }

?>
<section class="content" >


    <div class="row">
        <div class="col-xs-12">

            <?php

            if($response['message']=="Successful"){

                echo '<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-check"></i> Alert!</h4>
                Record Saved Successfully!
              </div>';
            }


            ?>


        </div>
        <div class="col-xs-12">
            <form name="user" method="post" >
                <div class="modal-content">
                    <div class="modal-header">
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                        <h4 class="modal-title" id="myModalLabel"><?php echo $action." ".ucfirst($module[0]); ?> </h4>
                        <div class="pull-right" style="margin-top: -25px;">
                            <a href="?page=payroll"><label class="btn btn-xs btn-info">back</label></a> 
                        </div>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-8">
                                <div class="form-group" style="margin-bottom: 0px; ">

                                    <?php if(isset($_GET['id'])): ?>
                                        <input type="hidden" class="form-control" name="id" value="<?php echo $_GET['id']; ?>" required />
                                        
                                    <?php endif; ?>
                                </div>

                                


                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Payroll Code</label>
                                    <input type="text" class="form-control" placeholder="Payroll Code" name="payroll_code" id="payroll_code" required value="<?php if(isset($_GET['id'])){ echo $rvalue['payroll_code']; } ?>"  readonly/>
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                <label>Date(s)</label>
                                    <input name="daterange" type="text" class="form-control pull-right" id="reservation"
                                     
                                     required=""> 
                                </div> 
                                <?php if(!isset($_GET['id'])): ?>
                                <div class="form-group">
                                    <label>Auto Generate Payslip?</label>
                                    <select class="form-control select2 select2-hidden-accessible" name="auto_payslip" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" >No</option>
                                      <option value="1" >Yes</option>
                                     
                                    </select>
                                </div>
                                <?php endif; ?>


                                  

                            </div>
                            <div class="col-sm-2"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="btn_save" class="btn btn-success fa fa-plus-square btn-sm" value="<?php echo $action; ?>">
                    </div>
                </div>
            </form>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->


<script>
    <?php if(!isset($_GET['id'])): ?>
        var pcode = makeCode();
        pcode = "ACP-"+pcode+"-<?php echo $np; ?>";
        $("#payroll_code").val(pcode);
    <?php endif; ?>
   
</script>