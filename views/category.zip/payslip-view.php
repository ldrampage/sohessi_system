
<script>


    function deleteThis(id){
        if (confirm('Are you sure you want to delete this?')) {
            window.location.href = window.location.href + '&del='+id;
        }
    }

    function setGetParameter(paramName, paramValue)
    {
        var url = window.location.href;
        var hash = location.hash;
        url = url.replace(hash, '');
        if (url.indexOf(paramName + "=") >= 0)
        {
            var prefix = url.substring(0, url.indexOf(paramName));
            var suffix = url.substring(url.indexOf(paramName));
            suffix = suffix.substring(suffix.indexOf("=") + 1);
            suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix.indexOf("&")) : "";
            url = prefix + paramName + "=" + paramValue + suffix;
        }
        else
        {
            if (url.indexOf("?") < 0)
                url += "?" + paramName + "=" + paramValue;
            else
                url += "&" + paramName + "=" + paramValue;
        }
        window.location.href = url + hash;
    }

    function reloadWithStatus(val){
        setGetParameter('istatus', val);
    }

</script>

<?php
$response['message']="";

if(isset($_GET['st'])){
    $udata = array("model"=>"payroll", "values"=>"status = '".$_GET['pid']."'", "condition"=>" WHERE id = '".$_GET['id']."'");
    $upn = $app->update2($udata);
}

if(isset($_POST['btn_ref'])){
    
    //echo json_encode($_POST);
    
    $fn = "";
    
    if(isset($_FILES["fileToUpload"]["name"])){
        $target_dir = "uploads/";
        //$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($_FILES["fileToUpload"]["name"], PATHINFO_EXTENSION);
        
        $fn = $app->RandomString().".".$imageFileType;
        $target_file = $target_dir.$fn;
        //echo $target_file;
        
           if ($_FILES["fileToUpload"]["size"] > 5000000) {
                $fn="";
            } 
            else {
                if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                }else{
                    $fn="";
                }
            }
            

    }
    
    if($fn==""){
        $updata = array("model"=>"payrollinclusive", 
              "values"=>"sendvia='".$_POST['sendvia']."',
                        reference_number = '".$_POST['reference_number']."'",
              "condition"=>" WHERE id = '".$_GET['pid']."'");
    }else{
        $updata = array("model"=>"payrollinclusive", 
              "values"=>"sendvia='".$_POST['sendvia']."',
                        reference_number = '".$_POST['reference_number']."',
                        attachment = '".$fn."'",
              "condition"=>" WHERE id = '".$_GET['pid']."'");
    }
    
    $upd = $app->update2($updata);
    
        $edata = array("model"=>"employee", "condition"=>" WHERE  id = '".$_GET['eid']."'");
        $theemps = $app->getRecord2($edata);
        $theemps = $theemps['data'][0];
        
        $rqdata = array("model"=>"payroll", "condition"=>" WHERE id = '".$_GET['id']."'");
        $dpayroll = $app->getRecord2($rqdata);
        $dpayroll = $dpayroll['data'][0];
        
        
        $rqdata = array("model"=>"payrollinclusive", "condition"=>" WHERE id = '".$_GET['pid']."'");
        $pslip = $app->getRecord2($rqdata);
        $pslip = $pslip['data'][0];
       
        $email_message="";
        $email_subject = " HR Management & Payroll System - Payment Reference";
        $name = $theemps['fname']." ".$theemps['lname'];
        $email_message .= '<html>';
        $email_message .= '<head><meta name="viewport" content="width=device-width" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
        $email_message .= '<style>';
        $email_message .='* {margin: 0;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;box-sizing: border-box;font-size: 14px;}img {max-width: 100%;}';
        $email_message .='body {background-color: #f6f6f6;}'; 
        $email_message .= 'table td {vertical-align: top;}.body-wrap {background-color: #f6f6f6; width: 100%;}.container {display: block !important;max-width: 600px !important;margin: 0 auto !important;clear: both !important;}';
        $email_message .= '.content {max-width: 600px; margin: 0 auto;display: block; padding: 20px;}';
        $email_message .= '.main {background-color: #fff;border: 1px solid #e9e9e9;border-radius: 3px;}.content-wrap { padding: 20px;}.content-block {padding: 0 0 20px;}';
        $email_message .= '.header {width: 100%;margin-bottom: 20px;}.footer { width: 100%;clear: both;color: #999;padding: 20px;}.footer p, .footer a, .footer td {color: #999; font-size: 12px;}';
        $email_message .= 'a {color: #348eda;text-decoration: underline;}';
        $email_message .= '.btn-primary { text-decoration: none;color: #FFF;background-color: #348eda;border: solid #348eda; border-width: 10px 20px;line-height: 2em;font-weight: bold;text-align: center;cursor: pointer;display: inline-block;border-radius: 5px;text-transform: capitalize;}';
    
        $email_message .= '</style>';
        $email_message .= '<title></title></head>';
        $email_message .= '<body itemscope itemtype="http://schema.org/EmailMessage" style="width: 100% !important; height: 100%; line-height: 1.6em;"><table class="body-wrap">';
       
        
        $email_message .= '<tr><td></td>';
        
        $email_message .= "<td class='container' width='600'><div class='content'><table class='main' width='100%' cellpadding='0' cellspacing='0'>";
        $email_message .= "<tr><td class='alert alert-warning'></td></tr><tr>";
        $email_message .= '<td class="content-wrap"><table width="100%" cellpadding="0" cellspacing="0">';
        
        $email_message .= "<tr><td><strong>Name: </strong> " . strip_tags($name) . "</td></tr>";
    	$email_message .= "<tr><td><strong>Payroll Code:  </strong> " . $dpayroll['payroll_code'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Inclusive Dates: </strong>" . date("M jS, Y", strtotime($dpayroll['datefrom']))." to ".date("M jS, Y", strtotime($dpayroll['dateto'])) . "</td></tr>";
    	$email_message .= "<tr><td><strong>Basic:  </strong> " . $pslip['monthly'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Bi-monthly:  </strong> " . ($pslip['monthly']/2) . " </td></tr>";
    	$email_message .= "<tr><td><strong>Incentives:  </strong> " . $pslip['incentives'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Deductions:  </strong> " . $pslip['deduction']. " </td></tr>";
    	$email_message .= "<tr><td><strong>Net Pay:  </strong> " . $pslip['total'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Note(s):  </strong> " . $pslip['notes'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Sent Via:  </strong> " . $pslip['sendvia'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Reference #:  </strong> " . $pslip['reference_number'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Attachment:  </strong> <a href='http://hr.backoffice-services.net/attachments.php?attc=".$pslip['attachment']."' class='btn-primary'>Click here</a> </td></tr>";
        $email_message .= '<tr><td class="content-block">'.EMAILFOOTER.'</td></tr></table></td></tr>';
    	
    	$email_message .= '	</td><td></td></tr></table>';	
    
    	$email_message .= "</body></html>";
    	
    	if($theemps['email_notify']==1){
        
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".EMAILSENDER." \r\n".
            "Reply-To: ".NOREPLY." \r\n" ;
        @mail($theemps['email'], $email_subject, $email_message, $headers);
    	}
    
    
}

$data = array("model"=>"payroll", "condition"=>" WHERE id = '".$_GET['id']."'");
$payroll=$app->getRecord2($data);
$payroll = $payroll['data'][0];

//echo json_encode($payroll);

$data = array("model"=>"payrollinclusive", "condition"=>" WHERE id = '".$_GET['pid']."'");
$payslip=$app->getRecord2($data);
$payslip = $payslip['data'][0];
//$eawards = json_decode($payroll['employee_id']);
$emps = $app->getEmployees();

$ps = $app->getPayrollStatus();


$inclusives = $app->getInclusives($payroll['id']);

 $tp=0;
 foreach($inclusives as $ke => $value){
    $tp = $tp + $value['total'];
 }


//echo json_encode($inclusives);
//exit();
?>

<?php
$color = "#000";

if($payroll['status']==0){ $bg = "bg-yellow"; }
else{  $bg = "bg-green";  }


?>

<section class="invoice">
    <!-- title row -->
    <div class="row">
        <div class="col-xs-12">
            <h2 class="page-header" style="color: <?php echo $color; ?>">
                <i class="fa fa-globe"></i>
                <?php
                
                
                 echo $emps[$_GET['eid']]['lname'].", ".$emps[$_GET['eid']]['fname']." (Payslip View)";
                ?>
                <small class="pull-right">Date: <?php echo date("Y")."-".date("m")."-".date("d"); ?></small>
            </h2>
            <div class="pull-right" style="margin-top: -75px;">
                            <a href="?page=payroll-view&id=<?php echo $_GET['id']; ?>"><label class="btn btn-xs btn-info">Back</label></a> 
                        </div>
        </div>
        <!-- /.col -->
    </div>
    <!-- info row -->
    <?php if($payroll['status']==1){ $dbg = "bg-green"; }else{ $dgb="bg-yellow"; } ?>
    <div class="row invoice-info">
        <div class="col-sm-6 invoice-col">
          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <form name="" action="" method="POST"  enctype="multipart/form-data">    
              <table class="table table-condensed">
                <tbody>
                <tr>
                  <th>Payroll Code</th>
                  <td><span class="badge bg-light-blue"><?php echo $payroll['payroll_code']; ?></span></td>
                </tr>
                <tr>
                  <th>Inclusive Dates</th>
                  <td><span class="badge bg-light-blue"> <?php
                 echo date("M jS, Y", strtotime($payroll['datefrom']))." to ".date("M jS, Y", strtotime($payroll['dateto'])); ?></span></td>
                </tr>
                
                <tr>
                  <th>Status</th>
                  <td><span class="badge <?php echo $dgb; ?>">
                        <?php 
                        echo $ps[$payroll['status']];
                        ?>
                  </span>    
                  </td>
                </tr>
                <tr>
                    <th>Sent Via</th>
                  <td><input type="text" name="sendvia" class="form-control input-sm" value="<?php echo $payslip['sendvia']; ?>" required>    
                 </td>
                </tr>
                <tr>
                  <th>Reference #</th>
                  <td><input type="text" name="reference_number" class="form-control input-sm" value="<?php echo $payslip['reference_number']; ?>" required>    
                  </td>
                </tr>
                <tr>
                  <td colspan="2" style="text-align: center; font-weight: bold;">Attach New To Alter
                  </td>
                </tr>
                <tr>
                  <th>Attachment:</th><?php if($payslip['attachment']!=""): $mwidth = "70%"; else: $mwidth="100%"; endif; ?>
                  <td><input type="file" name="fileToUpload" id="fileToUpload"  class="form-control input-sm"style="width: <?php echo $mwidth; ?>;">  
                  <?php if($payslip['attachment']!=""): ?><a class="pull-right" style="width: 20%; margin-top: -25px;" href="attachments.php?attc=<?php echo $payslip['attachment']; ?>" target="_BLANK">View</a><?php endif; ?>
                  </td>
                </tr>
                <tr>
                  <td colspan="2"><input type="submit" name="btn_ref" value="confirm" class="btn btn-success btn-xs pull-right" >  
                  </td>
                </tr>
              </tbody></table>
              
              </form>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col -->
        <div class="col-sm-6 invoice-col">
            <address>
                <div class="box-body no-padding">
                  <table class="table table-condensed">
                    <tbody>
                    <tr>
                      <th>Monthly</th>
                      <td><span class="badge bg-light-blue"><?php echo number_format($payslip['monthly'],2); ?></span></td>
                    </tr> 
                    <tr>
                      <th>Bi-Monthly</th>
                      <td><span class="badge bg-light-blue"><?php echo number_format($payslip['monthly']/2,2); ?></span></td>
                    </tr> 
                    <tr>
                      <th>Incentives</th>
                      <td><span class="badge bg-light-blue"><?php echo number_format($payslip['incentives'],2); ?></span></td>
                    </tr>
                    <tr>
                      <th>Deductions</th>
                      <td><span class="badge bg-light-blue"><?php echo number_format($payslip['deduction'],2); ?></span></td>
                    </tr> 
                    <tr>
                      <th>Total Amount</th>
                      <td><span class="badge bg-light-blue"><?php echo number_format($payslip['total'],2); ?></span></td>
                    </tr>
                    </tbody>
                  </table>
                </div>  
            </address>
        </div>
        
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->

</section>
<!-- /.content -->
