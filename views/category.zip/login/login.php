
<div class="login-box" style="height: 100%; min-height: 500px;">
<center><img src="<?php echo MAINURL; ?>/pnglogo.jpg" width="350px;"></center>
<div class="login-box-body" style="margin-top:5px;">

  <?php
  //require_once();
  //$obj = new mmlapi();

  if(isset($_POST['btn_login'])){

    //$data->inputs->uname
    $data = array('method'=>'login',
            'inputs'=>array(
                'uname'=>$_POST['login_user'],
                'upass'=>$_POST['login_pass']
              )
      );

    $data = $app->userLogin($data);
     if($data==0){

      echo '<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-ban"></i> Access Denied!</h4>
                Invalid Username Or Password!
              </div>';
    }elseif($data['status']==0){
      echo '<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-ban"></i> Access Denied!</h4>
                Sorry your employment is inactive!
              </div>';
    }else{
        $dsp = $app->getRecordById("department",$data['department_id']);
         
         $app->ACLsetDefault($data['id']);
        //echo json_encode($dsp); exit();

        $_SESSION['login_user'] = $data['fname'];
        $_SESSION['username'] = $data['un'];
        $_SESSION['login_photo'] = $data['image'];
        $_SESSION['login_designation'] = $data['position'];
        $_SESSION['login_department'] = $dsp['data'][0]['name'];
        $_SESSION['login_date'] = $data['last_session'];
        $_SESSION['login_id'] = $data['id'];
        $_SESSION['utype'] = $data['usertype'];
        
        //$du = array("model"=>"employee", "values"=>" last_session=");
        

        echo '<script>window.location = "index.php";</script>';
    }
  }


  ?>

    <p class="login-box-msg">Sign-in</p>

    <form  method="post" name="loginForm">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" placeholder="Username"  name="login_user"   required/>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password"  name="login_pass"  required/>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label style="margin-left: 16px;">
              <input type="checkbox" > Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <input type="submit" class="btn btn-primary btn-block btn-flat" value="Sign In" name="btn_login" />
        </div>
        <!-- /.col -->
      </div>
    </form>


</form> 
  </div>

  <br>

</div>

<!-- /.login-box -->

<!-- jQuery 2.2.3 -->


