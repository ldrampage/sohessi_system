
<script>


    function deleteThis(id){
        if (confirm('Are you sure you want to delete this?')) {
            window.location.href = window.location.href + '&del='+id;
        }
    }

    function setGetParameter(paramName, paramValue)
    {
        var url = window.location.href;
        var hash = location.hash;
        url = url.replace(hash, '');
        if (url.indexOf(paramName + "=") >= 0)
        {
            var prefix = url.substring(0, url.indexOf(paramName));
            var suffix = url.substring(url.indexOf(paramName));
            suffix = suffix.substring(suffix.indexOf("=") + 1);
            suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix.indexOf("&")) : "";
            url = prefix + paramName + "=" + paramValue + suffix;
        }
        else
        {
            if (url.indexOf("?") < 0)
                url += "?" + paramName + "=" + paramValue;
            else
                url += "&" + paramName + "=" + paramValue;
        }
        window.location.href = url + hash;
    }

    function reloadWithStatus(val){
        setGetParameter('istatus', val);
    }

</script>

<?php
$response['message']="";




$data = array("model"=>"attendance", "condition"=>" WHERE id = '".$_GET['id']."'");
$projects=$app->getRecord2($data);
$att = $projects['data'][0];
$eawards = json_decode($att['employee_id']);
$emps = $app->getEmployees();
$department = $app->getDepartments();
$myleave = $app->checkLeaveFromDate($att['employee_id'],$att['work_date']);
//echo json_encode($myleave);

?>

<?php
$color = "#000";
// if(strtoupper($clients['status'])=="LAUNCHED"){
//     $color = MYGREEN;
// }
// if(strtoupper($clients['status'])=="FINISHED"){
//     $color = MYBLUE;
// }
// if(strtoupper($clients['status'])=="WAITING"){
//     $color = MYGOLD;
// }
// if(strtoupper($clients['status'])=="FAILED"){
//     $color = MYRED;
// }


?>

<style type="text/css">
    
    .badge{
        padding: 3px 8px 3px 8px;
        font-size: 16px;
        border-radius: 3px;
    }

</style>

<section class="invoice">
    <!-- title row -->
    <div class="row">
        <div class="col-xs-12">
            <h2 class="page-header" style="color: <?php echo $color; ?>">
                <i class="fa fa-globe"></i>
                <?php
                 echo strtoupper($emps[$att['employee_id']]['fname'])." ".strtoupper($emps[$att['employee_id']]['lname'])." - ".strtoupper($emps[$att['employee_id']]['position'])." (Daily Attendance View)";
                ?>
                <small class="pull-right">Date: <?php echo date("Y")."-".date("m")."-".date("d"); ?></small>
            </h2>
        </div>
        <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
        <div class="col-sm-6 invoice-col">
          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
                <tbody>
                <tr>
                  <th>Name: </th>
                  <td><span class="badge bg-light-blue"><?php echo ucfirst($emps[$att['employee_id']]['fname'])." ".ucfirst($emps[$att['employee_id']]['lname']); ?></span></td>
                </tr>
                <tr>
                  <th>Department: </th>
                  <td><span class="badge bg-light-blue"><?php echo ucfirst($department[$emps[$att['employee_id']]['department_id']]['name']); ?></span></td>
                </tr>
                <tr>
                  <th>Position: </th>
                  <td><span class="badge bg-light-blue"><?php echo ucfirst($emps[$att['employee_id']]['position']); ?></span></td>
                </tr>
                <tr>
                  <th>Shift: </th>
                  <td><span class="badge bg-light-blue"><?php echo date('h:i:s a',strtotime($emps[$att['employee_id']]['shift_start']))." - ".date('h:i:s a',strtotime($emps[$att['employee_id']]['shift_end'])); ?></span></td>
                </tr>
                <tr>
                  <th>Attendance Date: </th>
                  <td><span class="badge bg-light-blue"><?php echo date("M jS, Y", strtotime($att['work_date'])) ?></span></td>
                </tr>
                <tr>
                  <th>Time-in:</th>
                  <td><span class="badge bg-light-blue"> <?php echo date('h:i:s a',strtotime($att['time_start'])); ?></span></td>
                </tr>
                <tr>
                  <th>Time-out</th>
                  <td><span class="badge bg-light-blue"><?php 

                         if($att['time_end']!="00:00:00"){
                                                    echo date('h:i:s a',strtotime($att['time_end']));
                         }

                   ?></span></td>
                </tr>
                <tr>
                  <th>Leave</th>
                  <td><span class="badge bg-light-blue" style="text-align: left;">
                  <?php
                    if(sizeOf($myleave)>0){ $c=0;
                        foreach ($myleave as $key => $value) { $c++;
                            echo "Duration: ".date("M jS, Y", strtotime($value['datefrom']))."-".date("M jS, Y", strtotime($value['dateto']))."<br>";
                            echo "Status: ".$value['status']."<br>";
                            echo "Type: ".$value['paidstate']."<br>";
                            echo "Reason: ".$value['reason']."<br>";
                        }
                    }else{
                        echo "N/A";
                    }
                    ?>
                  </span></td>
                </tr>
                <tr>
                <th>Note</th>
                  <td><span class="badge bg-light-blue"><?php echo $att['note']; ?></span></td>
                </tr>
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col -->
        <div class="col-sm-6 invoice-col">
            <address>

            </address>
        </div>
        
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->




<?php

if(isset($_GET['del'])){

    $data = array('model'=>'issues', 'condition'=>" WHERE id = '".$_GET['del']."'");
    $response = $app->delete2($data);
}





?>




    <br>

    <div class="row">

        <div class="col-md-12">


            <br>
            <div class="widget-content ">
                <div">

                <?php if( $response['message']=="Successful"){
                    echo '<br><div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">x</a>
                    <strong>Success!</strong> Record '.$daction.' successfully.
                </div>';
                }
                ?>



            </div>
            
        </div>
    </div>
</section>
<!-- /.content -->