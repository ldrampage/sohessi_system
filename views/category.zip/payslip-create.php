<!-- Main content -->
<?php

$response=array('action'=>"", 'message'=>"");
$rvalue =array();
$atvalue=array();
$devalue=array();
if(isset($_GET['pid'])){
    $atdd = array("model"=>"allowance",
                  "condition"=>" WHERE payslip_id = '".$_GET['pid']."'");
    $atvalue = $app->getRecord2($atdd);
    $atvalue = $atvalue['data'];

    $activea = array();

    foreach ($atvalue as $key => $value) {
        $activea[] = $value['id'];
    }

    $dedd = array("model"=>"deductions",
                  "condition"=>" WHERE payslip_id = '".$_GET['pid']."'");
    $devalue = $app->getRecord2($dedd);
    $devalue = $devalue['data'];

    $actived = array();

    foreach ($devalue as $key => $value) {
        $actived[] = $value['id'];
    }
}

if(isset($_POST['btn_save'])){
   
   //echo json_encode($_POST);




   

   if(isset($_POST['pid'])){

       $deductions = $_POST['deductions'];
       $amountd = $_POST['amountd'];
       if(isset($_POST['allowance'])){ 
         $allowance = $_POST['allowance'];
         $amounta = $_POST['amounta'];
         $theaids =  $_POST['theaid'];
         foreach($theaids as $aak => $aav){
            if(in_array($aav, $activea)){
                $ssvdata = array("model"=>"allowance", 
                                 "values"=>"legend='".$allowance[$aak]."', amount='".$amounta[$aak]."'",
                                 "condition"=>" WHERE id = '".$aav."'");
                $aupdate = $app->update2($ssvdata);
            }
            if($aav==0){
                $adata = array("model"=>"allowance", 
                              "keys"=>"payslip_id, legend, amount",
                              "values"=>"'".$_POST['pid']."','".$allowance[$aak]."', '".$amounta[$aak]."'"  );
               $ainsert = $app->create2($adata);
            }
         }
         foreach ($activea as $kact => $vact) {
             if(!in_array($vact, $theaids)){
                $deldata = array("model"=>"allowance", "condition"=>" WHERE id = '".$vact."'");
                $delete = $app->delete2($deldata);
             }
         }
       }else{ 
            $allowance=array(); 
            if(sizeOf($activea)>0){
                foreach ($activea as $key => $myaid) {
                    $deldata = array("model"=>"allowance", "condition"=>" WHERE id = '".$myaid."'");
                    $delete = $app->delete2($deldata);
                }
            }
        }
      

       if(isset($_POST['deductions'])){ 
         $deductions = $_POST['deductions'];
         $amountd = $_POST['amountd'];
         $thedids =  $_POST['thedid'];
         $absents =  $_POST['absents'];
         foreach($thedids as $aak => $aav){
            if(in_array($aav, $actived)){
                if($deductions[$aak]=="Hourly" || $deductions[$aak]=="Daily"){ $number = " number = '".$absents[0]."',"; }else{ $number=""; }
                $ssvdata = array("model"=>"deductions", 
                                 "values"=>"legend='".$deductions[$aak]."', $number amount='".$amountd[$aak]."'",
                                 "condition"=>" WHERE id = '".$aav."'");
                $aupdate = $app->update2($ssvdata);
            }
            if($aav==0){
                if($deductions[$aak]=="Hourly" || $deductions[$aak]=="Daily"){ $number = ", number"; $nva = ", '".$absents[0]."'"; }
                else{ $number=""; $nva = ""; }
                $adata = array("model"=>"deductions", 
                              "keys"=>"payslip_id, legend, amount $number",
                              "values"=>"'".$_POST['pid']."','".$deductions[$aak]."', '".$amountd[$aak]."' $nva"  );
               $ainsert = $app->create2($adata);
            }
         }
         foreach ($actived as $kact => $vact) {
             if(!in_array($vact, $thedids)){
                $deldata = array("model"=>"deductions", "condition"=>" WHERE id = '".$vact."'");
                $delete = $app->delete2($deldata);
             }
         }
       }
       
       
       $data = array("model"=>"payrollinclusive",
                     "values"=>"monthly='".$_POST['basic']."', incentives='".$_POST['tall']."', deduction='".$_POST['tdeduct']."', total='".$_POST['net']."', notes='".$_POST['notes']."'",
                     "condition"=>" WHERE id ='".$_GET['pid']."'"
                     );

       $insert = $app->update2($data);
       
       
       $edata = array("model"=>"employee", "condition"=>" WHERE  id = '".$_GET['eid']."'");
        $theemps = $app->getRecord2($edata);
        $theemps = $theemps['data'][0];
        
        $rqdata = array("model"=>"payroll", "condition"=>" WHERE id = '".$_GET['id']."'");
        $dpayroll = $app->getRecord2($rqdata);
        $dpayroll = $dpayroll['data'][0];
       
        $email_message="";
        $email_subject = " HR Management & Payroll System - Payslip (Update)";
        $name = $theemps['fname']." ".$theemps['lname'];
        $email_message .= '<html>';
        $email_message .= '<head><meta name="viewport" content="width=device-width" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
        $email_message .= '<style>';
        $email_message .='* {margin: 0;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;box-sizing: border-box;font-size: 14px;}img {max-width: 100%;}';
        $email_message .='body {background-color: #f6f6f6;}'; 
        $email_message .= 'table td {vertical-align: top;}.body-wrap {background-color: #f6f6f6; width: 100%;}.container {display: block !important;max-width: 600px !important;margin: 0 auto !important;clear: both !important;}';
        $email_message .= '.content {max-width: 600px; margin: 0 auto;display: block; padding: 20px;}';
        $email_message .= '.main {background-color: #fff;border: 1px solid #e9e9e9;border-radius: 3px;}.content-wrap { padding: 20px;}.content-block {padding: 0 0 20px;}';
        $email_message .= '.header {width: 100%;margin-bottom: 20px;}.footer { width: 100%;clear: both;color: #999;padding: 20px;}.footer p, .footer a, .footer td {color: #999; font-size: 12px;}';
        $email_message .= 'a {color: #348eda;text-decoration: underline;}';
        $email_message .= '.btn-primary { text-decoration: none;color: #FFF;background-color: #348eda;border: solid #348eda; border-width: 10px 20px;line-height: 2em;font-weight: bold;text-align: center;cursor: pointer;display: inline-block;border-radius: 5px;text-transform: capitalize;}';
    
        $email_message .= '</style>';
        $email_message .= '<title></title></head>';
        $email_message .= '<body itemscope itemtype="http://schema.org/EmailMessage" style="width: 100% !important; height: 100%; line-height: 1.6em;"><table class="body-wrap">';
       
        
        $email_message .= '<tr><td></td>';
        
        $email_message .= "<td class='container' width='600'><div class='content'><table class='main' width='100%' cellpadding='0' cellspacing='0'>";
        $email_message .= "<tr><td class='alert alert-warning'></td></tr><tr>";
        $email_message .= '<td class="content-wrap"><table width="100%" cellpadding="0" cellspacing="0">';
        
        $email_message .= "<tr><td><strong>Name: </strong> " . strip_tags($name) . "</td></tr>";
    	$email_message .= "<tr><td><strong>Payroll Code:  </strong> " . $dpayroll['payroll_code'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Inclusive Dates: </strong>" . date("M jS, Y", strtotime($dpayroll['datefrom']))." to ".date("M jS, Y", strtotime($dpayroll['dateto'])) . "</td></tr>";
    	$email_message .= "<tr><td><strong>Basic:  </strong> " . number_format(['basic'],2) . " </td></tr>";
    	$email_message .= "<tr><td><strong>Bi-monthly:  </strong> " . number_format($_POST['bi_basic'],2) . " </td></tr>";
    	$email_message .= "<tr><td><strong>Incentives:  </strong> " . number_format($_POST['tall'],2) . " </td></tr>";
    	$email_message .= "<tr><td><strong>Deductions:  </strong> " . number_format($_POST['tdeduct'],2). " </td></tr>";
    	$email_message .= "<tr><td><strong>Net Pay:  </strong> " . number_format($_POST['net'],2) . " </td></tr>";
    	$email_message .= "<tr><td><strong>Note(s):  </strong> " . $_POST['notes'] . " </td></tr>";
    	$email_message .= "<tr><td class='content-block'><a href='http://hr.backoffice-services.net/?page=profile' class='btn-primary'>Click here</a></td></tr>";
        $email_message .= '<tr><td class="content-block">'.EMAILFOOTER.'</td></tr></table></td></tr>';
    	
    	$email_message .= '	</td><td></td></tr></table>';	
    
    	$email_message .= "</body></html>";
        if($theemps['email_notify']==1 && $_POST['notify']==1){
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".EMAILSENDER." \r\n".
            "Reply-To: ".NOREPLY." \r\n" ;
        @mail($theemps['email'], $email_subject, $email_message, $headers);
        }


       if(isset($_POST['amounta'])){ $amounta = $_POST['amounta']; }else{ $amounta=array(); }
       $absents = $_POST['absents'];

   }else{

       $deductions=$_POST['deductions'];
       $absents=$_POST['absents'];
       $amountd=$_POST['amountd'];
       if(isset($_POST['allowance'])){ $allowance=$_POST['allowance']; $amounta=$_POST['amounta']; }else{ $allowance=array(); $amounta=array(); } 

       $data = array("model"=>"payrollinclusive",
                     "keys"=>"payroll_id,employee_id, monthly, incentives, deduction, total, notes",
                     "values"=>"'".$_GET['id']."', '".$_GET['eid']."', '".$_POST['basic']."', '".$_POST['tall']."', '".$_POST['tdeduct']."', '".$_POST['net']."', '".$_POST['notes']."'");

       $insert = $app->create2($data);

       foreach ($deductions as $key => $value) {
           //$totalD=$totalD+$amountd[$key];
           if($value=="Daily" || $value == "Hourly"){ $n=$absents[$key]; }else{ $n=0; }
           $ddata = array("model"=>"deductions", 
                          "keys"=>"payslip_id, legend, number, amount",
                          "values"=>"'".$insert['id']."','".$value."', '".$n."', '".$amountd[$key]."'" );
           $dinsert = $app->create2($ddata);
       }

       
       foreach ($allowance as $key => $value) {
           $adata = array("model"=>"allowance", 
                          "keys"=>"payslip_id, legend, amount",
                          "values"=>"'".$insert['id']."','".$value."', '".$amounta[$key]."'"  );
           $ainsert = $app->create2($adata);
       }
       
       
        $edata = array("model"=>"employee", "condition"=>" WHERE  id = '".$_GET['eid']."'");
        $theemps = $app->getRecord2($edata);
        $theemps = $theemps['data'][0];
        
        $rqdata = array("model"=>"payroll", "condition"=>" WHERE id = '".$_GET['id']."'");
        $dpayroll = $app->getRecord2($rqdata);
        $dpayroll = $dpayroll['data'][0];
       
        $email_message="";
        $email_subject = " HR Management & Payroll System - Payslip";
        $name = $theemps['fname']." ".$theemps['lname'];
        $email_message .= '<html>';
        $email_message .= '<head><meta name="viewport" content="width=device-width" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
        $email_message .= '<style>';
        $email_message .='* {margin: 0;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;box-sizing: border-box;font-size: 14px;}img {max-width: 100%;}';
        $email_message .='body {background-color: #f6f6f6;}'; 
        $email_message .= 'table td {vertical-align: top;}.body-wrap {background-color: #f6f6f6; width: 100%;}.container {display: block !important;max-width: 600px !important;margin: 0 auto !important;clear: both !important;}';
        $email_message .= '.content {max-width: 600px; margin: 0 auto;display: block; padding: 20px;}';
        $email_message .= '.main {background-color: #fff;border: 1px solid #e9e9e9;border-radius: 3px;}.content-wrap { padding: 20px;}.content-block {padding: 0 0 20px;}';
        $email_message .= '.header {width: 100%;margin-bottom: 20px;}.footer { width: 100%;clear: both;color: #999;padding: 20px;}.footer p, .footer a, .footer td {color: #999; font-size: 12px;}';
        $email_message .= 'a {color: #348eda;text-decoration: underline;}';
        $email_message .= '.btn-primary { text-decoration: none;color: #FFF;background-color: #348eda;border: solid #348eda; border-width: 10px 20px;line-height: 2em;font-weight: bold;text-align: center;cursor: pointer;display: inline-block;border-radius: 5px;text-transform: capitalize;}';
    
        $email_message .= '</style>';
        $email_message .= '<title></title></head>';
        $email_message .= '<body itemscope itemtype="http://schema.org/EmailMessage" style="width: 100% !important; height: 100%; line-height: 1.6em;"><table class="body-wrap">';
       
        
        $email_message .= '<tr><td></td>';
        
        $email_message .= "<td class='container' width='600'><div class='content'><table class='main' width='100%' cellpadding='0' cellspacing='0'>";
        $email_message .= "<tr><td class='alert alert-warning'></td></tr><tr>";
        $email_message .= '<td class="content-wrap"><table width="100%" cellpadding="0" cellspacing="0">';
        
        $email_message .= "<tr><td><strong>Name: </strong> " . strip_tags($name) . "</td></tr>";
    	$email_message .= "<tr><td><strong>Payroll Code:  </strong> " . $dpayroll['payroll_code'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Inclusive Dates: </strong>" . date("M jS, Y", strtotime($dpayroll['datefrom']))." to ".date("M jS, Y", strtotime($dpayroll['dateto'])) . "</td></tr>";
    	$email_message .= "<tr><td><strong>Basic:  </strong> " . $_POST['basic'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Bi-monthly:  </strong> " . ($_POST['basic']/2) . " </td></tr>";
    	$email_message .= "<tr><td><strong>Incentives:  </strong> " . $_POST['tall'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Deductions:  </strong> " . $_POST['tdeduct']. " </td></tr>";
    	$email_message .= "<tr><td><strong>Net Pay:  </strong> " . $_POST['net'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Note(s):  </strong> " . $_POST['notes'] . " </td></tr>";
    	$email_message .= "<tr><td class='content-block'><a href='http://hr.backoffice-services.net/?page=profile' class='btn-primary'>Click here</a></td></tr>";
        $email_message .= '<tr><td class="content-block">'.EMAILFOOTER.'</td></tr></table></td></tr>';
    	
    	$email_message .= '	</td><td></td></tr></table>';	
    
    	$email_message .= "</body></html>";
        if($theemps['email_notify']==1 && $_POST['notify']==1){
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".EMAILSENDER." \r\n".
            "Reply-To: ".NOREPLY." \r\n" ;
        @mail($theemps['email'], $email_subject, $email_message, $headers);
        }
   }
    
    /*
    $date = explode('-',$_POST['daterange']);
    $tmp = explode("/",trim($date[0]));
    $tmp1 = $tmp[2]."-".$tmp[0]."-".$tmp[1];
    //echo $tmp1;

    $tmp_ = explode("/",trim($date[1]));
    $tmp2 = $tmp_[2]."-".$tmp_[0]."-".$tmp_[1];
    
   

    $data = array('model'=>"payroll",'keys'=>"payroll_code, datefrom, dateto");

    if(isset($_POST['id'])){
        $data['values']="payroll_code = '".$_POST['payroll_code']."', datefrom = '".$tmp1."', dateto = '".$tmp2."'";
        $data['condition'] = " WHERE id = '".$_POST['id']."'";
        $response = $app->update2($data);
        //echo json_encode($response);
        echo "<script>location.href='index.php?page=payroll-view&id=".$_POST['id']."';</script>";
    }else{
        $date = date("Y")."-".date("m")."-".date("d");

        $data2 = array(
            'model'=>'payroll',
            'keys'=>"payroll_code, datefrom, dateto",
            'values'=>"'".$_POST['payroll_code']."', '".$tmp1."', '".$tmp2."'"
        );
        $response = $app->create2($data2);
        //echo json_encode($response);
        echo "<script>location.href='index.php?page=payroll-view&id=".$response['id']."';</script>";
        $response['message'] = "Successful";
       

      
    } */

}


if(isset($_GET['pid'])){
    $atdd = array("model"=>"allowance",
                  "condition"=>" WHERE payslip_id = '".$_GET['pid']."'");
    $atvalue = $app->getRecord2($atdd);
    $atvalue = $atvalue['data'];


    $dedd = array("model"=>"deductions",
                  "condition"=>" WHERE payslip_id = '".$_GET['pid']."'");
    $devalue = $app->getRecord2($dedd);
    $devalue = $devalue['data'];

   
}

if(isset($_GET['pid'])){
    $action = "Update";
    $rqdata = array("model"=>"payrollinclusive", "condition"=>" WHERE id = '".$_GET['pid']."'");
    $payslip = $app->getRecord2($rqdata);
    $rvalue = $payslip['data'][0];
}else{ $action = "Create"; }

if(isset($_GET['id'])){
    $rqdata = array("model"=>"payroll", "condition"=>" WHERE id = '".$_GET['id']."'");
    $payroll = $app->getRecord2($rqdata);
    $payroll = $payroll['data'][0];
}

$existingd = array("model"=>"payrollinclusive", "condition"=>" WHERE payroll_id = '".$_GET['id']."'");
$existing = $app->getRecord2($existingd);
$ext = array();
foreach($existing['data'] as $ekk => $evv){
    //echo json_encode($evv);
    $ext[] = $evv['employee_id'];
}


$emps = $app->getEmployees(" WHERE active_pay = '1'");
$leavetypes = $app->getLeavetypes();
$module = explode("-",$page);
$department = $app->getDepartments();
$inclusives = $app->getInclusives($payroll['id']);

$newEmp = array();
// foreach ($emps as $key => $value) {
//     echo json_encode($value)."<<<<br>";
//     if(!array_key_exists($key,$inclusives)){
//         $newEmp[$value['department_id']][] = $value;
//     }
// }
$basic = 0;
$totala = 0;
$totald=0;
$net = 0;
$bi_basic=0;
if(isset($_GET['eid'])){
    
    
    $edata2 = array("model"=>"employee", "condition"=>" WHERE  id = '".$_GET['eid']."'");
        $theemps2 = $app->getRecord2($edata2);
        $theemps2 = $theemps2['data'][0];


    $d_leave = array("model"=>"leave", 
                     "condition"=>" WHERE employee_id = '".$_GET['eid']."' AND ((datefrom >= '".$payroll['datefrom']."' AND datefrom <= '".$payroll['dateto']."') OR (dateto >= '".$payroll['datefrom']."' AND dateto <= '".$payroll['dateto']."'))",
                     "order"=>" ORDER BY datefrom ASC");
    $gleave = $app->getRecord2($d_leave);
    $gleave = $gleave['data'];

    //echo json_encode($gleave);


    $d_att = array("model"=>"attendance", 
                     "condition"=>" WHERE employee_id = '".$_GET['eid']."' AND (work_date >= '".$payroll['datefrom']."' AND work_date <= '".$payroll['dateto']."')",
                     "order"=>" ORDER BY work_date DESC");
    $gatt = $app->getRecord2($d_att);
    $gatt = $gatt['data'];

    //echo json_encode($gatt);
    //$i1 = new mckirby($seasonStart, $seasonEnd);
    //$i2 = new mckirby($userStart, $userEnd);
    //echo json_encode($emps[$_GET['eid']]);

    $myLeaves = $app->getLeaves($_GET['eid']);
    
    //$payroll['datefrom'] = "2017-08-10 00:00:00";
    //$payroll['dateto'] = "2017-08-11 00:00:00";
    $df = date('Y-m-d', strtotime($payroll['datefrom']));
    $dt = date('Y-m-d', strtotime($payroll['dateto']));
    
    //echo $df." ".$dt."<br>";
    
    $salary = $app->getMySalary($_GET['eid'], $dt);
    // foreach($salary as $skey => $sval){
    //     $dts = date('Y-m-d', strtotime($sval['dateto']));
    //     echo $dts." ? ".$dt."<br>";
    //     if($dts <= $dt){
    //         echo "<br>".json_encode($sval)."<=<br>";
    //     }else{
    //         echo "1<=<br>";
    //     }
    // }
   // echo "<br>".json_encode($salary)." ".$theemps2['monthly'];
    
    
    
    $monthly = $salary[0]['monthly'];
    
    //$thedaily = $emps[$_GET['eid']]['monthly']/20;
    $thedaily = $monthly/20;
    
    if(sizeOf($salary)==0){
        $monthly = $theemps2['monthly'];
    }
    
    //echo $monthly;

    if($emps[$_GET['eid']]['employee_type']==0){
       
        //$basic = $emps[$_GET['eid']]['monthly'];
        //$bi_basic  = $emps[$_GET['eid']]['monthly']/2;
        $basic = $monthly;
        $bi_basic  = $monthly/2;
    }else{
        $basic = $monthly;
        $bi_basic  = $monthly/2;
        //$workingdays = $app->number_of_working_days($payroll['datefrom'],$payroll['dateto']);
        //echo json_encode($workingdays);

    }
}
//echo json_encode($newEmp);


?>
<section class="content" >


    <div class="row">
        <div class="col-xs-12">

            <?php

            if($response['message']=="Successful"){

                echo '<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-check"></i> Alert!</h4>
                Record Saved Successfully!
              </div>';
            }


            ?>


        </div>



            <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <form name="" action="" method="POST">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            
            <h4 class="modal-title" id="myModalLabel"><label id="mtitle"></label></h4>
          </div>
          <div class="modal-body" id="mbody">
            
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
        </form>
      </div>
    </div>


        <a href data-toggle="modal" data-target="#myModal" id="triggerModal"></a>

        <div class="col-xs-12">
            <form name="user" method="post" >
                <?php
                if(isset($_GET['pid'])){
                    echo '<input type="hidden" name="pid" value="'.$_GET['pid'].'"">';
                }
                ?>

                <div class="modal-content">
                    <div class="modal-header">
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                        <b><h4><?php echo $action." ".ucfirst($module[0]); ?> (<?php echo date("M jS, Y", strtotime($payroll['datefrom']))."-".date("M jS, Y", strtotime($payroll['dateto'])); ?>)
                        </h4></b>
                        <div class="pull-right" style="margin-top: -35px;">
                            <a href="?page=payroll-view&id=<?php echo $_GET['id']; ?>"><label class="btn btn-xs btn-info">Back</label></a> 
                        </div>    
                    </div>

                    
                    <div class="modal-body">
                        <?php if(isset($_GET['eid'])): ?>    
                            <input type="hidden" name="therate" id="therate" value="<?php echo $emps[$_GET['eid']]['rate'];?>">
                            <input type="hidden" name="thedaily" id="thedaily" value="<?php echo $thedaily;?>">
                            <div class="row">
                                <div class="col-sm-6 invoice-col">
                                    <div class="box">
                                        <div class="box-header">
                                            <h3 class="box-title">Attendance</h3>
                                        </div>
                                        <!-- /.box-header -->
                                        <div class="box-body no-padding">
                                            <table class="table table-condensed">
                                              <tbody id="">
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Time-in</th>
                                                    <th>Time-out</th>
                                                    <th>Note</th>
                                                </tr>

                                                <?php
                                                    foreach ($gatt  as $key => $value) {
                                                        $includeLeave = "";    
                                                        if($value['leave_id']!=0){
                                                           $includeLeave = $leavetypes[$myLeaves[$value['leave_id']]['leavetype_id']]['name'];      
                                                        }

                                                        $title = "Attendance Details";

                                                        $info = '<b>Date: </b> '.date("M jS, Y", strtotime($value['work_date'])).'<br><b>Time-in: </b> '.date('h:i:s a',strtotime($value['time_start'])).'<br><b>Time-out: </b> '.date('h:i:s a',strtotime($value['time_start'])).'<br><b>Leave: </b> '.$includeLeave.'<br><b>Note(s): </b> '.$value['note'].'<br>';    

                                                        echo '
                                                            <tr>
                                                               <td>'.date("M jS, Y", strtotime($value['work_date'])).'</td>
                                                               <td>'.date('h:i:s a',strtotime($value['time_start'])).'</td>
                                                               <td>';

                                                                if($value['time_end']!="00:00:00"){
                                                                    echo date('h:i:s a',strtotime($value['time_end']));
                                                                }
                                                               echo '</td>
                                                               <td>';
                                                                    if(trim($value['note'])!="" || trim($value['leave_id'])!=0){
                                                                        echo '<a style ="cursor: pointer;"  onClick="modalValue(\''.$title.'\',\''.$info.'\')">View Notes</a>';
                                                                    } 
                                                               echo '</td>
                                                            </tr>
                                                        ';
                                                    }
                                                ?>
                                              </tbody>
                                            </table>  
                                        </div>
                                        <!-- /.box-body -->
                                    </div>
                                </div>
                                <div class="col-sm-6 invoice-col">
                                    <div class="box">
                                        <div class="box-header">
                                            <h3 class="box-title">Leave(s)</h3>
                                        </div>
                                        <!-- /.box-header -->
                                        <div class="box-body no-padding">
                                            <table class="table table-condensed">
                                              <tbody id="">
                                                <tr>
                                                    <th>Type</th>
                                                    <th>Status</th>
                                                    <th>Payable</th>
                                                    <th>Dates</th>
                                                    <th>Details</th>
                                                </tr>
                                                <?php
                                                    foreach ($gleave  as $key => $value) {

                                                        $title = "Leave Details";
                                                        $pyn = "No";
                                                        if(strtoupper($value['paidstate'])=="PAID"){
                                                                $pyn = "Yes";
                                                        }

                                                        $info = '<b>Type: </b> '.$leavetypes[$value['leavetype_id']]['name'].'<br><b>Date(s): </b> '.date("M jS, Y", strtotime($value['datefrom']))."-".date("M jS, Y", strtotime($value['dateto'])).'<br><b>Status: </b> '.ucfirst($value['status']).'<br><b>Payable: </b> '.$pyn.'<br><b>Reason(s): </b> '.$value['reason'].'<br>'; 

                                                        echo '
                                                            <tr>
                                                               <td>'.$leavetypes[$value['leavetype_id']]['name'].'</td>
                                                               <td>'.ucfirst($value['status']).'</td>
                                                               <td>'.$pyn.'</td>
                                                               <td>'.date("M jS, Y", strtotime($value['datefrom']))."-".date("M jS, Y", strtotime($value['dateto'])).'</td>
                                                               <td><a style ="cursor: pointer;"  onClick="modalValue(\''.$title.'\',\''.$info.'\')">View</a></td>
                                                            </tr>
                                                        ';
                                                    }
                                                ?>
                                              </tbody>
                                            </table>  
                                        </div>
                                        <!-- /.box-body -->
                                    </div>
                                </div>
                            </div>

                        <?php endif; ?>    
    


                        <div class="row">

                          <div class="col-sm-8">
                          <div class="row">

                            <div class="col-sm-12">

                                <div class="row">

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Department</label>
                                            <select class="form-control select2 select2-hidden-accessible" name="department_id" id="department_id" data-placeholder="Select Department" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                             <option>--SELECT--</option>
                                             <?php
                                                    $pc = 0;
                                                     foreach ($department as $key => $value) { $pc++;
                                                          $act="";
                                                         if(isset($_GET['did']) && $_GET['did']==$key){ $act="selected";}
                                                         echo "<option class='p".$pc." style='display: none;' value='".$key."' ".$act.">".$value['name']."</option>";
                                                     }
                                                    ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">        
                                        <div class="form-group">
                                            <label>Employee</label>
                                            <select class="form-control select2 select2-hidden-accessible"  data-placeholder="Select Employee" name="employee_id" style="width: 100%;" tabindex="-1" aria-hidden="true" id="employee_id" required>
                                            <option>--SELECT--</option>
                                            </select>   
                                        </div> 
                                    </div>
                                </div>         
                            </div>    

                                    <!-- <input name="daterange" type="text" class="form-control pull-right" id="reservation"
                                     
                                     required="">  -->
                            <?php if(isset($_GET['eid'])): ?>   

                            <div class="col-sm-12">
                                <div class="row invoice-info">
                                    <div class="col-sm-6 invoice-col">
                                      <div class="box">
                                        <div class="box-header">
                                          <h3 class="box-title">Incentives/Bonus</h3>
                                        </div>
                                        <!-- /.box-header -->
                                        <div class="box-body no-padding">
                                          <table class="table table-condensed">
                                          <tbody id="allbody">

                                          <?php 
                                            if(isset($_GET['pid'])): 
                                              $pcp=0; foreach ($atvalue as $atkey => $atvalue) { $pcp++;
                                              $mid = $app->RandomString2(4);
                                              $mid = $mid."-".$pcp;
                                              echo '<tr id="'.$mid.'"><th><input type="hidden" name="theaid[]" value="'.$atvalue['id'].'"><input type="text" name="allowance[]" placeholder="Type" class="form-control input-sm" value="'.$atvalue['legend'].'"" ></th><td><input type="number" name="amounta[]"  placeholder="Amount" value="'.$atvalue['amount'].'"  class="form-control cala input-sm"></td><td><button onClick="removeAl(\''.$mid.'\')" type="button" class="btn btn-block btn-default btn-xs">+ remove</button></td></tr>';
                                              
                                            } 
                                            endif;
                                            ?>

                                          
                                            
                                          </tbody></table>
                                          <br>
                                          <div class="row"><div class="col-sm-6">
                                          <button id="add_a" type="button" class="btn btn-block btn-default btn-xs col-sm-6">+ Add Incentives</button>
                                          </div><div class="col-sm-6">
                                          <button id="calculate_a" type="button" class="btn btn-block calculate_button btn-info btn-xs">Calculate</button>
                                          </div>

                                          </div>
                                          <br>
                                        </div>
                                        <!-- /.box-body -->
                                      </div>
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-sm-6 invoice-col">
                                        <div class="box">
                                            <div class="box-header">
                                              <h3 class="box-title">Deductions</h3>
                                            </div>
                                            <!-- /.box-header -->
                                            <div class="box-body no-padding">
                                              <table class="table table-condensed">
                                              <tbody id="alld">

                                              <?php 
                                                if(isset($_GET['pid'])): 
                                                  $pcp=0; foreach ($devalue as $atkey => $atvalue) { $pcp++;
                                                  $mid = $app->RandomString2(4);
                                                  $mid = $mid."-".$pcp;
                                                  if($atvalue['legend']=="Daily" || $atvalue['legend']=="Hourly"){
                                                    if($atvalue['legend']=="Daily"){$dsel="selected";$hsel="";}
                                                    else{$dsel="";$hsel="selected";}
                                                    echo '<tr>
                                                    <th>
                                                    <select name="deductions[]" style="height: 25px;" placeholder="Type" class="form-control input-sm" id="abs_type">
                                                        <option value="Daily" '.$dsel.'>Day(s) Absent</option>
                                                        <option value="Hourly" '.$hsel.'>Hour(s) Absent</option>
                                                    </select>
                                                    </th><td><input type="hidden" name="thedid[]" value="'.$atvalue['id'].'"><input value="'.$atvalue['number'].'" type="number" name="absents[]"  placeholder="Number"  class="form-control input-sm" id="abs_number"></td>
                                                    <td><input type="number" name="amountd[]"  placeholder="Amount"  class="form-control cald input-sm" value="'.$atvalue['amount'].'"  id="abs_amount"></td>
                                                </tr>';

                                                  }else{
                                                      echo '<tr id="'.$mid.'"><th colspan="2"><input type="hidden" name="thedid[]" value="'.$atvalue['id'].'"" ><input type="text" name="deductions[]" placeholder="Type" class="form-control input-sm" value="'.$atvalue['legend'].'"" ></th><td><input type="number" name="amountd[]"  placeholder="Amount" value="'.$atvalue['amount'].'"  class="form-control cald input-sm"></td><td><button onClick="removeAl(\''.$mid.'\')" type="button" class="btn btn-block btn-default btn-xs">+ remove</button></td></tr>';
                                                  } 
                                                  }
                                                  else: ?>
                                                <tr>
                                                    <th><input type="hidden" name="thedid[]" value="0">
                                                    <select name="deductions[]" style="height: 25px;" placeholder="Type" class="form-control input-sm" id="abs_type">
                                                        <option value="Daily">Day(s) Absent</option>
                                                        <option value="Hourly">Hour(s) Absent</option>
                                                    </select>
                                                    </th><td><input value="0" type="number" name="absents[]"  placeholder="Number"  class="form-control input-sm" id="abs_number"></td>
                                                    <td><input type="text" name="amountd[]"  placeholder="Amount"  class="form-control cald input-sm" value="0"  id="abs_amount"></td>
                                                </tr>
                                            <?php endif; ?>
                                              </tbody></table>

                                               <div class="row"><div class="col-sm-6">
                                                   <button id="add_d" type="button" class="btn btn-block btn-default btn-xs">+ Add Deduction</button>
                                                  </div><div class="col-sm-6">
                                                  <button id="calculate_a" type="button" class="btn btn-block calculate_button btn-info btn-xs">Calculate</button>
                                                  </div>

                                                  </div>
                                                  <br>

                                             
                                            </div>
                                        <!-- /.box-body -->
                                        </div>
                                    </div>
                                
                                <!-- /.col -->
                                </div>
                            </div>

                        <?php endif; ?>

                                <div class="col-sm-2"></div>
                                <div class="col-sm-8">
                                    
                                </div>
                                <div class="col-sm-2"></div>
                           </div>
                           </div>
                           <div class="col-sm-4">
                                <div class="box">
            
                                <!-- /.box-header -->
                                <div class="box-body no-padding">
                                  <table class="table table-condensed">
                                    <tbody>
                                    <tr>
                                      <th>Basic (Monthly)</th>
                                      <td><input type="text" name="basic" id="basic" value="<?php echo number_format($basic,2); ?>" class="form-control input-sm"required readonly/> 
                                      </td>
                                    </tr>
                                    <tr>
                                      <th>Bi-monthly</th>
                                      <td><input type="text" name="bi_basic" id="bi_basic" value="<?php echo number_format($bi_basic,2); ?>" class="form-control input-sm"required readonly/> 
                                      </td>
                                    </tr>
                                    <tr>
                                      <th>Total Allowance</th>
                                      <td><input type="text" name="tall" id="tall" class="form-control input-sm"   
                                        <?php if(isset($_GET['pid'])):
                                            echo "value='".number_format($rvalue['incentives'],2)."'";
                                        else: ?>
                                            value="0"
                                        <?php endif; ?>
                                       readonly required/></td>
                                    </tr>
                                    <tr>
                                      <th>Total Deductions</th>
                                      <td><input type="text" name="tdeduct" id="tdeduct" class="form-control input-sm"  
                                        <?php if(isset($_GET['pid'])):
                                            echo "value='".number_format($rvalue['deduction'],2)."'";
                                        else: ?>
                                            value="0"
                                        <?php endif; ?>    
                                       readonly required=""/></td>
                                    </tr>
                                    <tr>
                                      <th>Net Salary</th>
                                      <td><input type="text" name="net" id="net" class="form-control input-sm" 
                                        <?php if(isset($_GET['pid'])):
                                            echo "value='".number_format($rvalue['total'],2)."'";
                                        else: ?>
                                            value="0"
                                        <?php endif; ?>    
                                        readonly required=""/></td>
                                    </tr>
                                    
                                    
                                  </tbody></table>
                                </div>
                                <!-- /.box-body -->
                              </div>
                           </div>
                           <div class="col-md-12">
                             <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Note(s):</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <textarea class="form-control" placeholder="Note(s)" name="notes" required><?php if(isset($_GET['pid'])){ echo $rvalue['notes']; } ?> </textarea>
                                </div>
                              <div class="form-group">
                                    <label>Notify Via Email</label>
                                    <select class="form-control select2 select2-hidden-accessible" name="notify" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" >No</option>
                                      <option value="1" selected>Yes</option>
                                     
                                    </select>
                                </div>    
                           </div>  
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="btn_save" class="btn btn-success fa fa-plus-square btn-sm" value="<?php echo $action; ?>">
                    </div>
                </div>
            </form>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->


<script>

    function modalValue(title, details){
            //alert(title+" "+details);
           
            //$("#triggerModal").click();
            //$("#mtitle").remove();
            //$("#mbody").remove();
            $("#mtitle").html(title);
            $("#mbody").html(details);
            $("#triggerModal").click();
    }

    var addal = '<th><input type="hidden" name="theaid[]" value="0"><input type="text" name="allowance[]" placeholder="Type" class="form-control input-sm"></th><td><input type="number" name="amounta[]"  placeholder="Amount" value="0"  class="form-control cala input-sm"></td>';

    var addde = '<th colspan="2"><input type="hidden" name="thedid[]" value="0"><input type="text" name="deductions[]"  placeholder="Type" class="form-control input-sm"></th><td><input type="number" name="amountd[]"  placeholder="Amount"  value="0" class="form-control cald input-sm"></td>';

    <?php if(!isset($_GET['id'])): ?>
        var pcode = makeCode();
        pcode = "ACP-"+pcode+"-<?php echo $np; ?>";
        $("#payroll_code").val(pcode);
    <?php endif; ?>


    $("#add_a").click(function(){
        var alid = makeCode();
        var newAddAl = '<tr id="'+alid+'">'+addal+'<td><button onClick="removeAl(\''+alid+'\')" type="button" class="btn btn-block btn-default btn-xs">+ remove</button></td></tr>';
        $("#allbody").append(newAddAl);
    });

    $("#add_d").click(function(){
        var alid = makeCode();
        var newAddAl = '<tr id="'+alid+'">'+addde+'<td><button onClick="removeAl(\''+alid+'\')" type="button" class="btn btn-block btn-default btn-xs">+ remove</button></td></tr>';
        $("#alld").append(newAddAl);
    });


    $('.cal').on('input',function(e){
        //alert($(this).val());
        $('input[name="amounta"]').each(function() {
            alert($(this).val());
        });
    });


    $("#abs_type").on("change", function(){
        calculate_absent();
    });

    function calculate_absent(){
        var mytype = parseFloat($("#abs_type").val());
        var abs_number = parseFloat($("#abs_number").val());
        var abs_amount = parseFloat($("#abs_amount").val());
        var thedaily = parseFloat($("#thedaily").val());
        var therate = parseFloat($("#therate").val());
        if(abs_number==0){
            $("#abs_number").focus();
        }else{
            if(mytype=="Hourly"){
                abs_amount = therate * abs_number;
            }else{
                abs_amount = thedaily * abs_number;
            }
            $("#abs_amount").val(abs_amount);
        }
    }

    $("#abs_number").on("input", function(e){
        calculate_absent();
    });

    $(".calculate_button").click(function(){
        var deductions = 0;
        var allow = 0;
        $(".cald").each(function(){
            deductions = deductions + parseFloat($(this).val());
        });
        $("#tdeduct").val(deductions);
        $(".cala").each(function(){
            allow = allow + parseFloat($(this).val());
        });
        $("#tall").val(allow);
        var bi_basic = parseFloat($("#bi_basic").val());
        var net = bi_basic;
        net = net + allow;
        //alert(net);
        net = net -  deductions;
        $("#net").val(net);
        //alert(deductions);
    });

    function removeAl(theid) {
        $("#"+theid).remove();
    }

    $("#p1").removeAttr("style");

    <?php if(isset($_GET['did'])): ?>
        var did = $("#department_id").val();
        var options = "";
        
        <?php foreach ($emps as $key => $value) {  $p=""; if($key==$_GET['eid']){ $p="selected"; } ?>  

            if(did==<?php echo $value['department_id']; ?>){
                
                options = options + "<option value='<?php echo $value['id']; ?>' <?php echo $p; ?>><?php echo $value['fname']." ".$value['lname']." (".$value['position'].")"; ?></option>";

            }
            

        <?php  } ?>
        //console.log(options);
        $("#employee_id").append(options);
    <?php endif; ?>   

    $("#department_id").change(function(){
        var did = $(this).val();
        var options = "";

        $('#employee_id')
            .find('option')
            .remove()
            .end()
            .append('<option>--SELECT--</option>')
            //.val('whatever')
        ;
        
        <?php foreach ($emps as $key => $value) { if(!in_array($key, $ext)){  ?>  

            if(did==<?php echo $value['department_id']; ?>){ 

                options = options + "<option value='<?php echo $value['id']; ?>'><?php echo $value['fname']." ".$value['lname']." (".$value['position'].")"; ?></option>";

            }
            

        <?php } } ?>
        console.log(options);
        $("#employee_id").append(options);
    });



    $("#employee_id").change(function(){
        var did = $("#department_id").val();
        var eid = $(this).val();
        location.href = "index.php?page=payslip-create&id=<?php echo $_GET['id']; ?>&did="+did+"&eid="+eid;
    });

</script>