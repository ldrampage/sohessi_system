<section class="invoice">
    
    <?php
    
    
    if(isset($_POST['updateSet'])){
        $datal = array("model"=>"settings", 
                       "values"=>" setting_value = '".trim($_POST['lbreak'])."' ",
                       "condition"=>" WHERE setting_name = 'breakLunchSeconds'");
        $lb=$app->update2($datal);    
        $dataq = array("model"=>"settings", 
                       "values"=>" setting_value = '".trim($_POST['qbreak'])."' ",
                       "condition"=>" WHERE setting_name = 'breakSnackSeconds'");
        $qb=$app->update2($dataq);    
        $datap = array("model"=>"settings", 
                       "values"=>" setting_value = '".trim($_POST['pscreen'])."' ",
                       "condition"=>" WHERE setting_name = 'timerLimitSeconds'");
        $tl=$app->update2($datap);    
    }
    
    $d=array("model"=>"settings");
    $se=$app->getRecord($d);
    $se=$se['data'];
    $lbreak = 0;
    $qbreak = 0;
    $pscreen = 0;
    foreach($se as $k => $v){
        //echo $v['setting_name'];
        if($v['setting_name']=="breakLunchSeconds"){
            $lbreak = $v['setting_value'];
        }
        if($v['setting_name']=="breakSnackSeconds"){
            $qbreak = $v['setting_value'];
        }
        if($v['setting_name']=="timerLimitSeconds"){
            $pscreen = $v['setting_value'];
        }
    }
    
    ?>
    <!-- title row -->
    <div class="row">
        <div class="col-xs-12">
                <form class="form-horizontal"  name="" method="post" action=""  enctype="multipart/form-data">
                  <div class="row">
                  <div class="col-sm-5">
                      
                      <div class="form-group" style="margin-bottom: 0px; ">
                                <label>Lunch Break Time (Seconds)</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input id="un" type="text" class="form-control" placeholder="Lunch Break Time" name="lbreak" value="<?php echo $lbreak; ?>" required />
                                </div>
                       <div class="form-group" style="margin-bottom: 0px; ">         
                                <label>Quick Break Time (Seconds)</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input id="un" type="text" class="form-control" placeholder="Quick Break Time" name="qbreak" value="<?php echo $qbreak; ?>" required />
                              
                        </div> 
                        <div class="form-group" style="margin-bottom: 0px; ">         
                                <label>Printscreen Time inteerval (Seconds)</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input id="un" type="text" class="form-control" placeholder="Printscreen Time inteerval" name="pscreen"  value="<?php echo $pscreen; ?>" required />
                              
                        </div> 
                                
                                <?php if($_SESSION['acl']['settings-update']==1): ?>
                                <div class="form-group" >
                                    <button style="margin-top: 25px;" type="submit" class="btn btn-danger btn-sm" name="updateSet">Update</button>
                                </div>        
                                <?php endif; ?>
                                
                   </div>             
                   </div>
                            
                </form>
        </div>
    </div>
</div>    