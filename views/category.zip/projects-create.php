<!-- Main content -->
<?php

$response=array('action'=>"", 'message'=>"");

if(isset($_POST['btn_save'])){
    error_reporting(E_ALL); ini_set('display_errors', '1');
   //echo json_encode($_POST);
    $data = array('model'=>"projects",'keys'=>"project_name, project_description, employee_id");
    $employees = $_POST['employee_id'];
    if(isset($_POST['id'])){
        $data['values']="project_name = '".$_POST['name']."', project_description = '".$_POST['description']."', employee_id = '".json_encode($_POST['employee_id'])."'";
        $data['condition'] = " WHERE id = '".$_POST['id']."'";
        $response = $app->update2($data);
        
        $redata = array("model"=>"prolinks",
                        "condition"=>" WHERE project_id = '".$_POST['id']."'");
                        //echo "<br><br>".json_encode($redata);
        $retrieved = $app->getRecord2($redata);
        
        foreach($retrieved['data'] as $rtkey => $rtvalue){
            if(!in_array($rtvalue['employee_id'], $employees)){
                $delData = array("model"=>"prolinks", "condition"=>" WHERE id = '".$rtvalue['id']."'");
                $app->delete2($delData);
            }
        }
        
        foreach($employees as $ke => $ve){
            $redata = array("model"=>"prolinks",
                        "condition"=>" WHERE project_id = '".$_POST['id']."' AND employee_id = '".$ve."'");
            $retrieved = $app->getRecord2($redata);
           // echo "<br><br>".json_encode($retrieved);
            if(sizeOf($retrieved['data'])==0){
                $dpl = array("model"=>"prolinks",
                         "keys"=>"project_id, employee_id",
                         "values"=>"'".$_POST['id']."', '".$ve."'");
                $response2 = $app->create2($dpl);
            }
        }
        
    }else{
        $date = date("Y")."-".date("m")."-".date("d");

        $data2 = array(
            'model'=>'projects',
            'keys'=>'project_name, project_description, employee_id',
            'values'=>"'".$_POST['name']."', '".$_POST['description']."', '".json_encode($_POST['employee_id'])."'"
        );
        $response = $app->create2($data2);
        //echo "<br><br>".json_encode($response);
        foreach($employees as $ke => $ve){
            $dpl = array("model"=>"prolinks",
                         "keys"=>"project_id, employee_id",
                         "values"=>"'".$response['id']."', '".$ve."'");
            $response2 = $app->create2($dpl);
        }
        $response['message'] = "Successful";
      
    }

}
//$rvalue =array();
if(isset($_GET['id'])){
    $action = "Update";
    $rqdata = array("model"=>"projects", "condition"=>" WHERE id = '".$_GET['id']."'"); 
    $department = $app->getRecord2($rqdata);
    $rvalue = $department['data'][0];
    $rvalue['employee_id'] = json_decode($rvalue['employee_id']);
    //echo json_encode($rvalue);

}else{ $action = "Create"; }

$emps = $app->getEmployees();
$module = explode("-",$page);

?>
<section class="content" >


    <div class="row">
        <div class="col-xs-12">

            <?php

            if($response['message']=="Successful"){

                echo '<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-check"></i> Alert!</h4>
                Record Saved Successfully!
              </div>';
            }


            ?>


        </div>
        <div class="col-xs-12">
            <form name="user" method="post" >
                <div class="modal-content">
                    <div class="modal-header">
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                        <h4 class="modal-title" id="myModalLabel"><?php echo $action." ".ucfirst($module[0]); ?> </h4>
                        <div class="pull-right" style="margin-top: -25px;">
                            <a href="?page=projects"><label class="btn btn-xs btn-info">Project List</label></a> 
                        </div>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-8">
                                <div class="form-group" style="margin-bottom: 0px; ">

                                    <?php if(isset($_GET['id'])): ?>
                                        <input type="hidden" class="form-control" name="id" value="<?php echo $_GET['id']; ?>" required />
                                    <?php endif; ?>
                                </div>



                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Project Name</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="name" name="name" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['project_name']."'"; } ?> required />
                                </div>


                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Project Description</label>
                                    <textarea class="form-control" placeholder="description" name="description" required><?php if(isset($_GET['id'])){ echo $rvalue['project_description']; } ?></textarea>
                                </div>

                                <div class="form-group">
                                <label>Employee</label>
                                    <select class="form-control select2 select2-hidden-accessible" multiple="" data-placeholder="Select a Employee" name="employee_id[]" style="width: 100%;" tabindex="-1" aria-hidden="true" required>
                                        <?php
                                         foreach ($emps as $key => $value) {
                                              $act="";
                                             if(isset($_GET['id']) && in_array( $key , $rvalue['employee_id'] )){  $act="selected";}
                                             echo "<option value='".$key."' ".$act.">".$value['fname']." ".$value['lname']."</option>";
                                         }
                                        ?>
                                    </select>   
                                </div>    

                            </div>
                            <div class="col-sm-2"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="btn_save" class="btn btn-success fa fa-plus-square btn-sm" value="<?php echo $action; ?>">
                    </div>
                </div>
            </form>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->


