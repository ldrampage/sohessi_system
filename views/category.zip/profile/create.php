   <?php 
   error_reporting(E_ALL); ini_set('display_errors', 1); 
   $data=array("model"=>"employee");
   if(isset($_POST['updateme'])){
       $data['values']="fname = '".str_replace("'","\'",$_POST['fname'])."', 
                        mname = '".str_replace("'","\'",$_POST['mname'])."',
                        lname = '".str_replace("'","\'",$_POST['lname'])."',
                        mobilenumber = '".$_POST['mobilenumber']."',
                        email = '".$_POST['email']."',
                        address = '".str_replace("'","\'",$_POST['address'])."',
                        citytown = '".str_replace("'","\'",$_POST['citytown'])."',
                        province = '".str_replace("'","\'",$_POST['province'])."',
                        country = '".str_replace("'","\'",$_POST['country'])."',
                        zip = '".$_POST['zip']."',
                        birthdate = '".date("Y-m-d",strtotime($_POST['birthdate']))."',
                        emergency_contact = '".$_POST['emergency_contact']."',
                        emergency_mobile = '".$_POST['emergency_mobile']."',
                        saying = '".$_POST['saying']."',
                        skypeid= '".$_POST['skypeid']."'";                 
        $data['condition'] = " WHERE id ='".$_SESSION['login_id']."'";
        $response = $app->update2($data);
   }
 

   if(isset($_POST['changephoto'])){
       $target_dir = "uploads/";
       $newfilename = $app->RandomString(20);
        $target_file = $target_dir . basename($_FILES["file"]["name"]);
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        $target_file = $target_dir . $newfilename.".".$imageFileType;
 
        
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            echo "<script> alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.');</script>";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
             echo "<script> alert('Sorry, your file was not uploaded.');</script>";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
                echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
                $dataPar = array(
                   'photo'=>$target_file,
                   'id'=> $_SESSION['login_id']
                   );
               $app->updatePhoto($dataPar);
            } else {
                 echo "<script> alert('Sorry, there was an error uploading your file.');</script>";
            }
        }
   }
   
   
   $user=$app->getMyUsers($_SESSION['login_id']); 
   //echo json_encode($user); 
   $user=$user[0];
   $department = $app->getDepartments();
    $condition = " WHERE uid = '". $_SESSION['login_id']."'";

   $pays = $app->getPayslips("employee_id", $_SESSION['login_id']);

    // $ds = array(
    //     'model'=>'tickets',
    //     'condition'=>$condition
    // );
    // $cur = $app->getRecord2($ds);
    // $tickets=$cur['data'];
    $tickets=array();
   ?>
   

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo $user['image']; ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $user['fname']; ?></h3>

              <p class="text-muted text-center"><?php echo $user['position']; ?></p>
              <p class="text-muted text-center" style="font-size: 12px; margin-top: -6px;"><?php echo $department[$user['department_id']]['name']; ?></p>

              <!--<ul class="list-group list-group-unbordered">-->
              <!--  <li class="list-group-item">-->
              <!--    <b>Followers</b> <a class="pull-right">1,322</a>-->
              <!--  </li>-->
              <!--  <li class="list-group-item">-->
              <!--    <b>Following</b> <a class="pull-right">543</a>-->
              <!--  </li>-->
              <!--  <li class="list-group-item">-->
              <!--    <b>Friends</b> <a class="pull-right">13,287</a>-->
              <!--  </li>-->
              <!--</ul>-->

              <!--<a href="#" class="btn btn-primary btn-block"><b>Follow</b></a>-->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">About Me</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> Saying</strong>

              <p class="text-muted">
                <?php echo $user['saying']; ?>
              </p>

              <hr>

              <strong><i class="fa fa-map-marker margin-r-5"></i> Location</strong>

              <p class="text-muted"><?php echo $user['address']."<br>".$user['citytown']."<br>".$user['province']."<br>".$user['country']."<br>".$user['zip']; ?></p>

              <hr>

              <!--<strong><i class="fa fa-pencil margin-r-5"></i> Skills</strong>-->

              <!--<p>-->
              <!--  <span class="label label-danger">UI Design</span>-->
              <!--  <span class="label label-success">Coding</span>-->
              <!--  <span class="label label-info">Javascript</span>-->
              <!--  <span class="label label-warning">PHP</span>-->
              <!--  <span class="label label-primary">Node.js</span>-->
              <!--</p>-->

              <!--<hr>-->

              <!--<strong><i class="fa fa-file-text-o margin-r-5"></i> Notes</strong>-->

              <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam fermentum enim neque.</p>-->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab">Payments</a></li>
              <!--<li><a href="#timeline" data-toggle="tab">Timeline</a></li>-->
              <li><a href="#settings" data-toggle="tab">User Info</a></li>
              <li><a href="#photo" data-toggle="tab">Photo</a></li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                  
                
                <ul class="timeline">
            <!-- timeline time label -->
            <li class="time-label">
                  <!-- <span class="bg-red">
                   #1
                  </span> -->
            </li>
            <!-- /.timeline-label -->
            <!-- timeline item -->
            
            
             
                <?php foreach($pays as $k => $v): 
                $pstat=$app->getPayrollStatus();
                if($v['status']==0){ $bsg = "bg-yellow"; }
                else{ $bsg = "bg-aqua"; }
                ?>  
                <li>
                  <i class="fa fa-money <?php echo $bsg; ?>"></i>

                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-clock-o"></i><?php echo date("M jS, Y", strtotime($v['datefrom']))."-".date("M jS, Y", strtotime($v['dateto'])); ?></span>

                    <h3 class="timeline-header"><a href="#">Payroll Code</a> <?php echo $v['payroll_code']; ?></h3>
                    <div class="timeline-body">
                      <b>Basic:</b> <?php echo number_format($v['monthly'],2); ?><br>
                      <b>Bi-monthly:</b> <?php echo number_format($v['monthly']/2,2); ?><br>
                      <b>Incentives:</b> <?php echo number_format($v['incentives'],2); ?><br>
                      <b>Deductions:</b> <?php echo number_format($v['deduction'],2); ?><br>
                      <b>Total:</b> <?php echo number_format($v['total'],2); ?><br>
                      <b>Status:</b> <label class="<?php echo $bsg; ?>" style="padding: 3px 5px 3px 5px;"><?php echo $pstat[$v['status']]; ?></label><br> 
                      <b>Note:</b> <?php echo $v['notes']; ?><br>
                      <?php
                      
                      if(trim($v['sendvia'])!="" || trim($v['reference_number'])!=""){
                          echo '<b>Sent Via:</b> '.$v['sendvia'].'<br>';
                          echo '<b>Reference #:</b> '.$v['reference_number'].'<br>';
                      }
                      if(trim($v['attachment'])!=""){
                          echo "<a href='attachments.php?attc=".$v['attachment']."' target='_BLANK'>View Attachment</a>";
                      }
                      
                      ?>
                    </div>
                    <!-- <div class="timeline-footer">
                      <a class="btn btn-primary btn-xs">Read more</a>
                      <a class="btn btn-danger btn-xs">Delete</a>
                    </div> -->
                  </div>
                </li>
                <?php endforeach; ?>
                <!-- /.post -->
                 <i class="fa fa-clock-o bg-gray"></i>
                </li>
              </ul>

               
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="timeline">
                <!-- The timeline -->
                <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-red">
                          10 Feb. 2014
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-envelope bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-user bg-aqua"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 5 mins ago</span>

                      <h3 class="timeline-header no-border"><a href="#">Sarah Young</a> accepted your friend request
                      </h3>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-comments bg-yellow"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 27 mins ago</span>

                      <h3 class="timeline-header"><a href="#">Jay White</a> commented on your post</h3>

                      <div class="timeline-body">
                        Take me to your leader!
                        Switzerland is small and neutral!
                        We are more like Germany, ambitious and misunderstood!
                      </div>
                      <div class="timeline-footer">
                        <a class="btn btn-warning btn-flat btn-xs">View comment</a>
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline time label -->
                  <li class="time-label">
                        <span class="bg-green">
                          3 Jan. 2014
                        </span>
                  </li>
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-camera bg-purple"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 2 days ago</span>

                      <h3 class="timeline-header"><a href="#">Mina Lee</a> uploaded new photos</h3>

                      <div class="timeline-body">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                        <img src="http://placehold.it/150x100" alt="..." class="margin">
                      </div>
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <li>
                    <i class="fa fa-clock-o bg-gray"></i>
                  </li>
                </ul>
              </div>
              <!-- /.tab-pane -->
              
              <div class="tab-pane" id="settings">
                <form class="form-horizontal"  name="" method="post" action="">
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">First Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputName" placeholder="First Name"  name="fname" value='<?php echo $user['fname']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Middle Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputName" placeholder="Middle Name"  name="mname" value='<?php echo $user['mname']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Last Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputName" placeholder="Last Name"  name="lname" value='<?php echo $user['lname']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Mobile Number</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputEmail" placeholder="mobilenumber"  name="mobilenumber" value='<?php echo $user['mobilenumber']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Skype ID</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputEmail" placeholder="Skype ID"  name="skypeid" value='<?php echo $user['skypeid']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Email</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputEmail" placeholder="Email"  name="email" value='<?php echo $user['email']; ?>' readonly>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Address Line 1</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Address" name="address"  value="<?php echo $user['address']; ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">City/Town</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="City/Town" name="citytown"  value='<?php echo $user['citytown']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Province</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Province" name="province"  value='<?php echo $user['province']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Country</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Country" name="country"  value='<?php echo $user['country']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Zip</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Zip" name="zip"  value='<?php echo $user['zip']; ?>'>
                    </div>
                  </div>
                  <div class="form-group">
                        <label for="inputSkills" class="col-sm-2 control-label">Birth Date</label>
                        <div class="col-sm-10">
                            <div class="input-group date col-sm-12">
                                      <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                      </div>
                                      <input type="text" class="form-control pull-right" name="birthdate" id="datepicker3" <?php if(isset($_GET['id'])){ echo "value='".date("m/d/Y",strtotime($user['birthdate']))."'"; } ?> required>
                            </div>
                        </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Contact In Case Of Emergency</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Contact In Case Of Emergency" name="emergency_contact"  value='<?php echo $user['emergency_contact']; ?>'>
                    </div>
                  </div>   
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Emergency Contact #</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Emergency Contact #" name="emergency_mobile"  value='<?php echo $user['emergency_mobile']; ?>'>
                    </div>
                  </div>   
                  <div class="form-group">
                    <label for="inputExperience" class="col-sm-2 control-label">Saying</label>

                    <div class="col-sm-10">
                      <textarea class="form-control" id="inputExperience" placeholder="Saying" name="saying" ><?php echo $user['saying']; ?></textarea>
                    </div>
                  </div>
                  
                 
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger" name="updateme">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
              
              
              <div class="tab-pane" id="photo">
                <form class="form-horizontal"  name="" method="post" action=""  enctype="multipart/form-data">
                  
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Upload Photo</label>

                    <div class="col-sm-10">
                      <input type="file" class="form-control" id="file" placeholder="Photo" name="file"  value='<?php echo $user['photo']; ?>'>
                    </div>
                  </div>
           
                  
                 
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger" name="changephoto">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
              
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
  