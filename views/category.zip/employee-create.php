<!-- Main content -->
<?php

$response=array('action'=>"", 'message'=>"");
if(isset($_POST['btn_save'])){

    $data = array('model'=>"employee",
        'keys'=>"fname, mname, lname, email, address, position, date_hired, date_regularized, shift_start, shift_end, hrs, rate, monthly, un, up, employee_type, department_id, 
            dayswork,
            signedoffer,
            idproof,
            timeproof_email,
            timeproof_installed,
            citytown,
            province,
            country,
            zip,
            firstpaydate,
            birthdate,
            emergency_contact,
            emergency_mobile,
            mobilenumber");

    if(isset($_POST['id'])){
        $data['values']="fname = '".str_replace("'","\'",$_POST['fname'])."', 
                        mname = '".str_replace("'","\'",$_POST['mname'])."',
                        lname = '".str_replace("'","\'",$_POST['lname'])."',
                        email = '".str_replace("'","\'",$_POST['email'])."',
                        address = '".str_replace("'","\'",$_POST['address'])."',
                        position = '".str_replace("'","\'",$_POST['position'])."',
                        date_hired = '".date('y-m-d',strtotime($_POST['date_hired']))."',
                        date_regularized = '".date('y-m-d',strtotime($_POST['date_regularized']))."',
                        shift_start = '".date("H:i", strtotime($_POST['shift_start']))."',
                        shift_end = '".date("H:i", strtotime($_POST['shift_end']))."',
                        hrs = '".$_POST['hrs']."',
                        rate = '".$_POST['rate']."',
                        employee_type = '".$_POST['employee_type']."',
                        department_id = '".$_POST['department_id']."',
                        monthly = '".$_POST['monthly']."',

                        dayswork = '".str_replace("'","\'",$_POST['dayswork'])."',
                        signedoffer = '".$_POST['signedoffer']."',
                        idproof = '".$_POST['idproof']."',
                        timeproof_email = '".$_POST['timeproof_email']."',
                        timeproof_installed = '".$_POST['timeproof_installed']."',
                        citytown = '".str_replace("'","\'",$_POST['citytown'])."',
                        province = '".str_replace("'","\'",$_POST['province'])."',
                        country = '".str_replace("'","\'",$_POST['country'])."',
                        zip = '".str_replace("'","\'",$_POST['zip'])."',
                        firstpaydate = '".date('y-m-d',strtotime($_POST['firstpaydate']))."',
                        birthdate = '".date('y-m-d',strtotime($_POST['birthdate']))."',
                        emergency_contact = '".str_replace("'","\'",$_POST['emergency_contact'])."',
                        emergency_mobile = '".$_POST['emergency_mobile']."',
                        mobilenumber = '".$_POST['mobilenumber']."' ,
                        subdepartment_id = '".$_POST['subdepartment_id']."',
                        	auto_payslip = '".$_POST['auto_payslip']."',
                        	email_notify = '".$_POST['email_notify']."',
                        active_pay = '".$_POST['active_pay']."',
                        skypeid = '".$_POST['skypeid']."'
                        
                        
                        ";
        if(isset($_POST['un'])){ if(trim($_POST['un']!="")){  $data['values'] = $data['values'].", un = '".trim($_POST['un'])."'"; }  }
        if(isset($_POST['up'])){  if(trim($_POST['up']!="")){   $data['values'] = $data['values'].", up = '".sha1(trim($_POST['up']))."'"; }      }           
        $data['condition'] = " WHERE id = '".$_POST['id']."'";
        $response = $app->update2($data);
    }else{


        $date = date("Y")."-".date("m")."-".date("d");

        $data2 = array(
            'model'=>'employee',
            'keys'=>"fname, mname, lname, email, address, position, date_hired, date_regularized, shift_start, shift_end, hrs, rate, monthly, un, up, employee_type, department_id, image, 
                dayswork,
                signedoffer,
                idproof,
                timeproof_email,
                timeproof_installed,
                citytown,
                province,
                country,
                zip,
                firstpaydate,
                birthdate,
                emergency_contact,
                emergency_mobile,
                mobilenumber,
                subdepartment_id,
                auto_payslip,
                email_notify,
                active_pay,
                employee_number,
                skypeid",
            'values'=>"'".str_replace("'","\'",$_POST['fname'])."', 
                       '".str_replace("'","\'",$_POST['mname'])."', 
                       '".str_replace("'","\'",$_POST['lname'])."', 
                       '".str_replace("'","\'",$_POST['email'])."', 
                       '".str_replace("'","\'",$_POST['address'])."', 
                       '".str_replace("'","\'",$_POST['position'])."', 
                       '".date('Y-m-d',strtotime($_POST['date_hired']))."', 
                       '".date('Y-m-d',strtotime($_POST['date_regularized']))."', 
                       '".date("H:i", strtotime($_POST['shift_start']))."', 
                       '".date("H:i", strtotime($_POST['shift_end']))."', 
                       '".$_POST['hrs']."', 
                       '".$_POST['rate']."', 
                       '".$_POST['monthly']."',
                       '".trim($_POST['un'])."', 
                       '".sha1(trim($_POST['up']))."', 
                       '".$_POST['employee_type']."', 
                       '".$_POST['department_id']."', 
                       'uploads/user.png',
                '".str_replace("'","\'",$_POST['dayswork'])."',
                '".str_replace("'","\'",$_POST['signedoffer'])."',
                '".$_POST['idproof']."',
                '".$_POST['timeproof_email']."',
                '".$_POST['timeproof_installed']."',
                '".str_replace("'","\'",$_POST['citytown'])."',
                '".str_replace("'","\'",$_POST['province'])."',
                '".str_replace("'","\'",$_POST['country'])."',
                '".str_replace("'","\'",$_POST['zip'])."',
                '".date('y-m-d',strtotime($_POST['firstpaydate']))."',
                '".date('y-m-d',strtotime($_POST['birthdate']))."',
                '".str_replace("'","\'",$_POST['emergency_contact'])."',
                '".$_POST['emergency_mobile']."',
                '".$_POST['mobilenumber']."',
                '".$_POST['subdepartment_id']."',
                '".$_POST['auto_payslip']."',
                '".$_POST['email_notify']."',
                '".$_POST['active_pay']."',
                '".$app->createID()."',
                '".$_POST['skypeid']."'"
        );
        $response = $app->create2($data2);
        $response['message'] = "Successful";
        $email_message="";
        $email_subject = " HR Management & Payroll System Login Credentials";
        $name = $_POST['fname']." ".$_POST['lname'];
        $email_message .= '<html>';
        $email_message .= '<head><meta name="viewport" content="width=device-width" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
        $email_message .= '<style>';
        $email_message .='* {margin: 0;font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;box-sizing: border-box;font-size: 14px;}img {max-width: 100%;}';
        $email_message .='body {background-color: #f6f6f6;}'; 
        $email_message .= 'table td {vertical-align: top;}.body-wrap {background-color: #f6f6f6; width: 100%;}.container {display: block !important;max-width: 600px !important;margin: 0 auto !important;clear: both !important;}';
        $email_message .= '.content {max-width: 600px; margin: 0 auto;display: block; padding: 20px;}';
        $email_message .= '.main {background-color: #fff;border: 1px solid #e9e9e9;border-radius: 3px;}.content-wrap { padding: 20px;}.content-block {padding: 0 0 20px;}';
        $email_message .= '.header {width: 100%;margin-bottom: 20px;}.footer { width: 100%;clear: both;color: #999;padding: 20px;}.footer p, .footer a, .footer td {color: #999; font-size: 12px;}';
        $email_message .= 'a {color: #348eda;text-decoration: underline;}';
        $email_message .= '.btn-primary { text-decoration: none;color: #FFF;background-color: #348eda;border: solid #348eda; border-width: 10px 20px;line-height: 2em;font-weight: bold;text-align: center;cursor: pointer;display: inline-block;border-radius: 5px;text-transform: capitalize;}';
    
        $email_message .= '</style>';
        $email_message .= '<title></title></head>';
        $email_message .= '<body itemscope itemtype="http://schema.org/EmailMessage" style="width: 100% !important; height: 100%; line-height: 1.6em;"><table class="body-wrap">';
       
        
        $email_message .= '<tr><td></td>';
        
        $email_message .= "<td class='container' width='600'><div class='content'><table class='main' width='100%' cellpadding='0' cellspacing='0'>";
        $email_message .= "<tr><td class='alert alert-warning'></td></tr><tr>";
        $email_message .= '<td class="content-wrap"><table width="100%" cellpadding="0" cellspacing="0">';
        
        $email_message .= "<tr><td><strong>Name: </strong> " . strip_tags($name) . "</td></tr>";
    	$email_message .= "<tr><td><strong>Username:  </strong> " . $_POST['un'] . " </td></tr>";
    	$email_message .= "<tr><td><strong>Password: </strong>" . $_POST['up'] . "</td></tr>";
    	$email_message .= "<tr><td class='content-block'><a href='http://hr.backoffice-services.net/?page=login' class='btn-primary'>Click here</a></td></tr>";
        $email_message .= '<tr><td class="content-block">'.EMAILFOOTER.'</td></tr></table></td></tr>';
    	
    	$email_message .= '	</td><td></td></tr></table>';	
    
    	$email_message .= "</body></html>";
        if($_POST['email_notify']==1){
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".EMAILSENDER." \r\n".
            "Reply-To: ".NOREPLY." \r\n" ;
        @mail($_POST['email'], $email_subject, $email_message, $headers);
        }
      
    }

}
//$rvalue =array();
if(isset($_GET['id'])){
    $action = "Update";
    $rqdata = array("model"=>"employee", "condition"=>" WHERE id = '".$_GET['id']."'");
    $department = $app->getRecord2($rqdata);
    $rvalue = $department['data'][0];
    //echo json_encode($rvalue);

}else{ $action = "Create"; }


$department = $app->getDepartments();
//echo json_encode($department);

$sdpt = $app->getSubDepartments();

$module = explode("-",$page);

?>

<style>
.form-group {
 margin-bottom: 0px; 
}
</style>
<section class="content" >


    <div class="row">
        <div class="col-xs-12">

            <?php

            if($response['message']=="Successful"){

                echo '<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-check"></i> Alert!</h4>
                Record Saved Successfully!
              </div>';
            }


            ?>


        </div>
        <div class="col-xs-12">
            <form name="user" method="post" >
                <div class="modal-content">
                    <div class="modal-header">
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                        <h4 class="modal-title" id="myModalLabel"><?php echo $action." ".ucfirst($module[0]); ?> </h4>
                        <div class="pull-right" style="margin-top: -25px;">
                            <a href="?page=<?php echo $_GET['b']; ?><?php if(isset($_GET['bid'])){ echo "&".$_GET['bk']."=".$_GET['bid']; } ?><?php if(isset($_GET['bid2'])){ echo "&".$_GET['bk2']."=".$_GET['bid2']; } ?>"><label class="btn btn-xs btn-info">Back</label></a> 
                        </div>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-sm-3">
                                <div class="form-group" style="margin-bottom: 0px; ">

                                    <?php if(isset($_GET['id'])): ?>
                                        <input type="hidden" class="form-control" name="id" value="<?php echo $_GET['id']; ?>" required />
                                    <?php endif; ?>
                                </div>



                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>First Name</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="First Name" id="fname" name="fname" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['fname']."'"; } ?> required />
                                </div>

                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Middle Name</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Middle Name" name="mname" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['mname']."'"; } ?>  />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Last Name</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Last Name" name="lname" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['lname']."'"; } ?> required />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Email</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="email" class="form-control" placeholder="Email" name="email" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['email']."'"; } ?> required />
                                </div>

                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Mailing Address</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Address" name="address" <?php if(isset($_GET['id'])){ echo 'value="'.$rvalue['address'].'"'; } ?> />
                                </div>

                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>City/Town</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="City/Town" name="citytown" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['citytown']."'"; } ?> />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Province</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Province" name="province" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['province']."'"; } ?> />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Country</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Country" name="country" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['country']."'"; } ?> />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Zip</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Zip" name="zip" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['zip']."'"; } ?> />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Skype ID</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Skype ID" name="skypeid" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['skypeid']."'"; } ?> />
                                </div>

                            </div>
                            <div class="col-sm-3">
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Mobile Number:</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Mobile Number" name="mobilenumber" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['mobilenumber']."'"; } ?> />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Birth Date</label>
                                    <div class="input-group date">
                                      <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                      </div>
                                      <input type="text" class="form-control pull-right" name="birthdate" id="datepicker3" <?php if(isset($_GET['id'])){ echo "value='".date("m/d/Y",strtotime($rvalue['birthdate']))."'"; } ?> >
                                    </div>
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>In case of Emergency Contact:</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Contact Name" name="emergency_contact" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['emergency_contact']."'"; } ?> />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Emergency Contact Number:</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Contact Number" name="emergency_mobile" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['emergency_mobile']."'"; } ?> />
                                </div>

                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Position</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Position" name="position" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['position']."'"; } ?> />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Date Hired</label>
                                    

                                    <div class="input-group date">
                                      <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                      </div>
                                      <input type="text" class="form-control pull-right" name="date_hired" id="datepicker" <?php if(isset($_GET['id'])){ echo "value='".date("m/d/Y",strtotime($rvalue['date_hired']))."'"; } ?> >
                                    </div>
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Date Regularized</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <div class="input-group date">
                                      <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                      </div>
                                      <input type="text" class="form-control pull-right" name="date_regularized" id="datepicker2" <?php if(isset($_GET['id'])){ echo "value='".date("m/d/Y",strtotime($rvalue['date_regularized']))."'"; } ?>>
                                    </div>
                                </div>
                                <div class="form-group">
                                  <label>Shift Start:</label>

                                  <div class="input-group">

                                    <input type="text" class="form-control timepicker" name="shift_start" <?php if(isset($_GET['id'])){ echo "value='".date("g:i a", strtotime($rvalue['shift_start']))."'"; } ?> >

                                    <div class="input-group-addon">
                                      <i class="fa fa-clock-o"></i>
                                    </div>
                                  </div>
                                  <!-- /.input group -->
                                </div>
                                <div class="form-group">
                                  <label>Shift End:</label>

                                  <div class="input-group">
                                    <input type="text" class="form-control timepicker" name="shift_end" <?php if(isset($_GET['id'])){ echo "value='".date("g:i a", strtotime($rvalue['shift_end']))."'"; } ?> >

                                    <div class="input-group-addon">
                                      <i class="fa fa-clock-o"></i>
                                    </div>
                                  </div>
                                  <!-- /.input group -->
                                </div>
                                
                                <div class="form-group">
                                <label>Department</label>
                                    <select class="form-control select2 select2-hidden-accessible"  data-placeholder="Select a Department" name="department_id" id="department_id" style="width: 100%;" tabindex="-1" aria-hidden="true" required>
                                        <?php
                                         foreach ($department as $key => $value) {
                                              $act="";
                                             if(isset($_GET['id']) && $rvalue['department_id']==$key){ $act="selected";}
                                             if(isset($_GET['department-id']) && $_GET['department-id']==$key){ $act="selected";}
                                             echo "<option value='".$key."' ".$act.">".$value['name']."</option>";
                                         }
                                        ?>
                                    </select>   
                                </div>      
                                
                            </div>
                            <div class="col-sm-3">
                                

                                <div class="form-group">
                                    <label>Sub Department</label>
                                    <select class="form-control select2 select2-hidden-accessible" id="subdepartment_id" name="subdepartment_id" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                     
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Employee Type</label>
                                    <select class="form-control select2 select2-hidden-accessible" id="employee_type" name="employee_type" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" <?php if(isset($_GET['id'])){ if($rvalue['employee_type']==0){ echo "selected"; } }else{ echo "selected"; } ?>>Full-time</option>
                                      <option value="1" <?php if(isset($_GET['id'])){ if($rvalue['employee_type']==1){ echo "selected"; } } ?>>Part time</option>
                                     
                                    </select>
                                </div>

                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Days Working</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="text" class="form-control" placeholder="Days Working" name="dayswork" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['dayswork']."'"; } ?> />
                                </div>

                                <div class="form-group">
                                    <label>Signed Offer</label>
                                    <select class="form-control select2 select2-hidden-accessible" id="signedoffer" name="signedoffer" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" <?php if(isset($_GET['id'])){ if($rvalue['signedoffer']==0){ echo "selected"; } }else{ echo "selected"; } ?>>No</option>
                                      <option value="1" <?php if(isset($_GET['id'])){ if($rvalue['signedoffer']==1){ echo "selected"; } } ?>>Yes</option>
                                     
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>ID Proof</label>
                                    <select class="form-control select2 select2-hidden-accessible" id="idproof" name="idproof" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" <?php if(isset($_GET['id'])){ if($rvalue['idproof']==0){ echo "selected"; } }else{ echo "selected"; } ?>>No</option>
                                      <option value="1" <?php if(isset($_GET['id'])){ if($rvalue['idproof']==1){ echo "selected"; } } ?>>Yes</option>
                                     
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>TimeProof Installed</label>
                                    <select class="form-control select2 select2-hidden-accessible" id="timeproof_installed" name="timeproof_installed" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" <?php if(isset($_GET['id'])){ if($rvalue['timeproof_installed']==0){ echo "selected"; } }else{ echo "selected"; } ?>>No</option>
                                      <option value="1" <?php if(isset($_GET['id'])){ if($rvalue['timeproof_installed']==1){ echo "selected"; } } ?>>Yes</option>
                                     
                                    </select>
                                </div>

                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Timeproof Email</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input type="email" class="form-control" placeholder="Timeproof Email" name="timeproof_email" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['timeproof_email']."'"; } ?> />
                                </div>

                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>First Pay Date</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <div class="input-group date">
                                      <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                      </div>
                                      <input type="text" class="form-control pull-right" name="firstpaydate" id="datepicker4" <?php if(isset($_GET['id'])){ echo "value='".date("m/d/Y",strtotime($rvalue['firstpaydate']))."'"; } ?>>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Auto Generate Payslip (Payroll)</label>
                                    <select class="form-control select2 select2-hidden-accessible" id="auto_payslip" name="auto_payslip" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" <?php if(isset($_GET['id'])){ if($rvalue['auto_payslip']==0){ echo "selected"; } }else{ echo "selected"; } ?>>No</option>
                                      <option value="1" <?php if(isset($_GET['id'])){ if($rvalue['auto_payslip']==1){ echo "selected"; } } ?>>Yes</option>
                                     
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Auto Notify via Email</label>
                                    <select class="form-control select2 select2-hidden-accessible" id="email_notify" name="email_notify" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" <?php if(isset($_GET['id'])){ if($rvalue['email_notify']==0){ echo "selected"; } }else{ echo "selected"; } ?>>No</option>
                                      <option value="1" <?php if(isset($_GET['id'])){ if($rvalue['email_notify']==1){ echo "selected"; } } ?>>Yes</option>
                                     
                                    </select>
                                </div>
                                
                                
                            </div>
                            <div class="col-sm-3">
                                
                                
                                <div class="form-group">
                                    <label>Include on Payslip Creation</label>
                                    <select class="form-control select2 select2-hidden-accessible" id="active_pay" name="active_pay" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                      <option value="0" <?php if(isset($_GET['id'])){ if($rvalue['active_pay']==0){ echo "selected"; } }else{ echo "selected"; } ?>>No</option>
                                      <option value="1" <?php if(isset($_GET['id'])){ if($rvalue['active_pay']==1){ echo "selected"; } } ?>>Yes</option>
                                     
                                    </select>
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Hrs/Week</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input id="hrs" type="text" class="form-control" placeholder="Hours/Week" name="hrs" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['hrs']."'"; } ?> required />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Rate/Hr</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input  id="rate" type="text" class="form-control" placeholder="Hourly Rate" name="rate" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['rate']."'"; } ?> required />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Rate/Month</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input  id="monthly" type="text" class="form-control" placeholder="Monthly Rate" name="monthly" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['monthly']."'"; } ?> required />
                                </div>

                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Username</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input id="un" type="text" class="form-control" placeholder="username" name="un" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['un']."'"; } ?> required />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label> <?php if(isset($_GET['id'])){ echo "(Please leave blank to retain password)"; }else{ echo "Password"; } ?></label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input id="pw" type="text" class="form-control" placeholder="password" name="up" <?php if(isset($_GET['id'])){ echo "value=''"; }else{ echo "required"; } ?>  />
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="btn_save" class="btn btn-success fa fa-plus-square btn-sm" value="<?php echo $action; ?>">
                    </div>
                </div>
            </form>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->


<script>


function calculate(param){
    var hrs = $("#hrs").val();
    var rate = $("#rate").val();
    var monthly = $("#monthly").val();
    var employee_type = $('#employee_type').val();
    if(employee_type==0){
        $('#rate').attr('readonly', 'true');
        //$('#rate').val(0);
        $('#monthly').removeAttr('readonly');
        if(hrs=="" || hrs==0){
            
            alert("Please enter number of hours first!");
            $("#hrs").focus();
        }else{
            rate = (monthly/4) / hrs;
            $("#rate").val(rate);
        }
    }else{
        $('#monthly').attr('readonly', 'true');
        //$('#monthly').val(0);
        $('#rate').removeAttr('readonly');
        if(hrs=="" || hrs==0){
            alert("Please enter number of hours first!");
            $("#hrs").focus();
        }else{
            monthly = (rate * hrs) * 4;
            $("#monthly").val(monthly);
        }
    }
    
}

$("#department_id").on("change", function(e){
        var did = $(this).val();
        var options = "";

        $('#subdepartment_id')
            .find('option')
            .remove()
            .end()
            .append('<option>--SELECT--</option>')
            //.val('whatever')
        ;
        
        <?php foreach ($sdpt as $key => $value) {  ?>  

            if(did==<?php echo $value['department_id']; ?>){ 

                options = options + "<option value='<?php echo $value['id']; ?>'><?php echo $value['name']; ?></option>";

            }
            

        <?php } ?>
        //console.log(options);
        $("#subdepartment_id").append(options);
});

<?php if(isset($_GET['id'])): ?>
function setDefault(){
        var did = $("#department_id").val();
        var options = "";

        $('#subdepartment_id')
            .find('option')
            .remove()
            .end()
            .append('<option>--SELECT--</option>')
            //.val('whatever')
        ;
        
        <?php foreach ($sdpt as $key => $value) {  if($_GET['sid']==$value['id']){ $s="selected"; }else{ $s=""; } ?>  

            if(did==<?php echo $value['department_id']; ?>){ 

                options = options + "<option value='<?php echo $value['id']; ?>' <?php echo $s; ?>><?php echo $value['name']; ?></option>";

            }
            

        <?php }  ?>
        console.log(options);
        $("#subdepartment_id").append(options);
    }
    setDefault();
<?php endif; ?>


$('#fname').on('change',function(e){
    var un = $(this).val();
    <?php if(!isset($_GET['id'])): ?>
        var ext = makeUser();
        var pass = makeRandom();
        un = un.substring(0,3) + ext;
        $("#un").val(un);
        $("#pw").val(pass);
    <?php endif; ?>

});
$('#rate').on('input',function(e){
    calculate("rate");
});
$('#monthly').on('input',function(e){
    calculate("monthly");
});
$('#hrs').on('input',function(e){
    calculate("hrs");
});
$('#employee_type').on('change',function(e){
    var employee_type = $(this).val();
    var param = "monthly";
    //alert(employee_type);
    if(employee_type==0){
        $('#rate').val(0);
        param = "monthly";
    }else{
        $('#monthly').val(0);
        param = "rate";
    }
    calculate(param);
});

</script>