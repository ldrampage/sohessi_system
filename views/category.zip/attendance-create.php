<!-- Main content -->
<?php

$response=array('action'=>"", 'message'=>"");
$date = date('Y-m-d', time());
if(isset($_POST['btn_save'])){
   //echo json_encode($_POST);
    $data = array('model'=>"attendance",'keys'=>"name, description, department_id");
    $ctime = date('h:i:s a', time());   
    
    $ctime = date("H:i", strtotime($ctime));
    if(isset($_POST['id'])){
        $data['values']="time_end = '".$ctime."', note = '".$_POST['note']."'";
        $data['condition'] = " WHERE id = '".$_POST['id']."'";
        $response = $app->update2($data);
    }else{
        $date = date("Y")."-".date("m")."-".date("d");
        $data2 = array(
             "model"=>"attendance",
             'keys'=>'time_start, note, employee_id, work_date',
             'values'=>"'".$ctime."', '".$_POST['note']."', '".$_SESSION['login_id']."', '".$date."'"
        );
        $response = $app->create2($data2);
        $response['message'] = "Successful";
    }

}



if(isset($_GET['id'])){
     $rqdata = array("model"=>"attendance", "condition"=>" WHERE id = '".$_GET['id']."'");
    $att = $app->getRecord2($rqdata);
    $rvalue = $att['data'][0];
    $action = "Time-out";
}else{
    $rqdata = array("model"=>"attendance", "condition"=>" WHERE employee_id = '".$_SESSION['login_id']."' AND work_date = '".$date."'");
    $att = $app->getRecord2($rqdata);
    $rvalue=array();
    $action = "Time-in";
}



//echo json_encode($rvalue);
$ctime = date('h:i:s a', time());   
$ctime = date("H:i", strtotime($ctime));
$department = $app->getDepartments();
$emps = $app->getEmployees();
$module = explode("-",$page);

?>
<section class="content" >


    <div class="row">
        <div class="col-xs-12">

            <?php

            if($response['message']=="Successful"){

                echo '<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-check"></i> Alert!</h4>
                '.$action.' Saved Successfully!
              </div>';
            }


            ?>


        </div>
        <div class="col-xs-12">
            <form name="user" method="post" >
                <div class="modal-content">
                    <div class="modal-header">
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                        <h4 class="modal-title" id="myModalLabel"><?php echo $action." ".ucfirst($module[0]); ?> </h4>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-8">
                                <?php if(isset($_GET['id'])): ?>
                                    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
                                <?php endif; ?>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                        <div class="form-group" style="margin-bottom: 0px; ">
                                        <label>Date:</label>
                                        <input type="text" class="form-control" name="date" value="<?php echo $date; ?>" required readonly/>
                                        </div>
                                </div> 
                                <div class="form-group" style="margin-bottom: 0px; ">
                                        <div class="form-group" style="margin-bottom: 0px; ">
                                        <label>Time:</label>
                                        <input type="text" class="form-control" name="time" value="<?php echo $ctime; ?>" required readonly/>
                                        </div>
                                </div>    
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Note(s)</label>
                                    <textarea class="form-control" placeholder="Notes" name="note"><?php if($action == "Time-out"){ echo $rvalue['note']; } ?></textarea>
                                </div>

                                

                            </div>
                            <div class="col-sm-2"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="btn_save" class="btn btn-success fa fa-plus-square btn-sm" value="<?php echo $action; ?>">
                    </div>
                </div>
            </form>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->


