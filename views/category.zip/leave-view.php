
<script>


    function deleteThis(id){
        if (confirm('Are you sure you want to delete this?')) {
            window.location.href = window.location.href + '&del='+id;
        }
    }

    function setGetParameter(paramName, paramValue)
    {
        var url = window.location.href;
        var hash = location.hash;
        url = url.replace(hash, '');
        if (url.indexOf(paramName + "=") >= 0)
        {
            var prefix = url.substring(0, url.indexOf(paramName));
            var suffix = url.substring(url.indexOf(paramName));
            suffix = suffix.substring(suffix.indexOf("=") + 1);
            suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix.indexOf("&")) : "";
            url = prefix + paramName + "=" + paramValue + suffix;
        }
        else
        {
            if (url.indexOf("?") < 0)
                url += "?" + paramName + "=" + paramValue;
            else
                url += "&" + paramName + "=" + paramValue;
        }
        window.location.href = url + hash;
    }

    function reloadWithStatus(val){
        setGetParameter('istatus', val);
    }

</script>

<?php
$response['message']="";

if(isset($_POST['status'])){
     $data = array('model'=>"leave",'keys'=>"employee_id, datefrom, dateto, leavetype_id, status");

        $data['values']="status = '".$_POST['status']."'";
        $data['condition'] = " WHERE id = '".$_GET['id']."'";
        $response = $app->update2($data);
}


$data = array("model"=>"leave", "condition"=>" WHERE id = '".$_GET['id']."'");
$projects=$app->getRecord2($data);
$leave = $projects['data'][0];
$eawards = json_decode($leave['employee_id']);
$emps = $app->getEmployees();
$leavetypes = $app->getLeavetypes();
$leaveStatus = $app->getLeaveStatus();
//echo json_encode($projects);

//exit();
?>

<?php
$color = "#000";
if($leave['status']=="filed"){
    $color = MYGOLD;
}
// if(strtoupper($clients['status'])=="FINISHED"){
//     $color = MYBLUE;
// }
// if(strtoupper($clients['status'])=="WAITING"){
//     $color = MYGOLD;
// }
if($leave['status']=="approved"){
    $color = MYGREEN;
}
if($leave['status']=="canceled"){
    $color = MYRED;
}
?>

<section class="invoice">
    <!-- title row -->
    <div class="row">
        <div class="col-xs-12">
            <h2 class="page-header" style="color: <?php echo $color; ?>">
                <i class="fa fa-globe"></i>
                <?php
                 echo strtoupper($emps[$leave['employee_id']]['fname'])." ".strtoupper($emps[$leave['employee_id']]['lname'])." (Leave Application View)";
                ?>
                <small class="pull-right">Date: <?php echo date("Y")."-".date("m")."-".date("d"); ?></small>
            </h2>
        </div>
        <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
        <div class="col-sm-6 invoice-col">
            <address>
                <strong><h4><?php echo $emps[$leave['employee_id']]['fname']." ".$emps[$leave['employee_id']]['mname']." ".$emps[$leave['employee_id']]['lname']; ?></h4></strong>
                <b>Date(s):</b> <?php echo date("M jS, Y", strtotime($leave['datefrom']))."-".date("M jS, Y", strtotime($leave['dateto'])); ?> <br>
                <b>Status:</b> <a style="color: <?php echo $color; ?>"><?php echo $leave['status']; ?></a><br>
                <b>Reason:</b> <?php echo $leave['reason']; ?><br>
                
            </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
        </div>
        <div class="col-sm-2 invoice-col">
            <address>
            <?php  if($_SESSION['acl']['leave-approval']==1): ?>
                                       
              <form name="" method="POST" action="" id="changeState">
                  <select name="status" class="form-control pull-right" id="status">
                      <?php foreach ($leaveStatus as $key => $value) {
                           $se="";
                           if($leave['status']==$value){ $se= "selected"; }
                          echo "<option value='$value' $se>".ucfirst($value)."</option>";
                      } ?>
                  </select>
              </form>
          <?php endif; ?>
            </address>
        </div>
        
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->




<?php

if(isset($_GET['del'])){

    $data = array('model'=>'issues', 'condition'=>" WHERE id = '".$_GET['del']."'");
    $response = $app->delete2($data);
}





?>




    <br>

    <div class="row">

        
    </div>
</section>
<!-- /.content -->
<script>
    
    $("#status").on("change", function(e){
        $("#changeState").submit();
    });

</script>