<!-- Main content -->
<?php

$response=array('action'=>"", 'message'=>"");
if(isset($_POST['btn_save'])){
    
    //echo json_encode($_POST); exit();
    if($_POST['present']=="on"){ $dateto = "0000-00-00"; }
    else{ $dateto = date('y-m-d',strtotime($_POST['dateto'])); }
    //$dateto = date('y-m-d',strtotime($_POST['dateto']));
    
    $data = array('model'=>"salary",
        'keys'=>"");

    if(isset($_GET['id'])){
        $data['values']="hrs = '".$_POST['hrs']."',
                        rate = '".$_POST['rate']."',
                        monthly = '".$_POST['monthly']."',
                        datefrom = '".date('y-m-d',strtotime($_POST['datefrom']))."',
                        dateto = '".$dateto."'
                        ";
        $data['condition'] = " WHERE id = '".$_GET['id']."'";
        $response = $app->update2($data);
    }else{


        $date = date("Y")."-".date("m")."-".date("d");

        $data2 = array(
            'model'=>'salary',
            'keys'=>"hrs, rate, monthly, datefrom, dateto, employee_id",
            'values'=>"'".$_POST['hrs']."', 
                       '".$_POST['rate']."', 
                       '".$_POST['monthly']."', 
                       '".date('y-m-d',strtotime($_POST['datefrom']))."',
                       '".$dateto."', 
                       '".$_GET['eid']."'"
        );
        $response = $app->create2($data2);
        $response['message'] = "Successful";
      
    }
    
    if($_POST['present']=="on"){
        $data = array('model'=>"employee",
                      'values'=>"hrs = '".$_POST['hrs']."', rate = '".$_POST['rate']."', monthly = '".$_POST['monthly']."'",
                      "condition"=>" WHERE id = '".$_GET['eid']."'");
        $updates = $app->update2($data);              
    }

}
//$rvalue =array();
if(isset($_GET['id'])){
    $action = "Update";
    $rqdata = array("model"=>"salary", "condition"=>" WHERE id = '".$_GET['id']."'");
    $department = $app->getRecord2($rqdata);
    $rvalue = $department['data'][0];
    //echo json_encode($rvalue);

}else{ $action = "Create"; }


$department = $app->getDepartments();
$theemps = $app->getEmployees();

$sdpt = $app->getSubDepartments();

$module = explode("-",$page);

?>

<style>
.form-group {
 margin-bottom: 0px; 
}
</style>
<section class="content" >


    <div class="row">
        <div class="col-xs-12">

            <?php

            if($response['message']=="Successful"){

                echo '<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><i class="icon fa fa-check"></i> Alert!</h4>
                Record Saved Successfully!
              </div>';
            }


            ?>


        </div>
        <div class="col-xs-12">
            <form name="user" method="post" >
                
                <div class="modal-content">
                    <div class="modal-header">
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                        <h4 class="modal-title" id="myModalLabel"><?php echo $action." ".ucfirst($module[0]); ?> (<?php echo $theemps[$_GET['eid']]['fname']." ".$theemps[$_GET['eid']]['lname']; ?>)</h4>
                        <div class="pull-right" style="margin-top: -25px;">
                            <a href="?page=employee-view&id=<?php echo $_GET['eid']; ?>"><label class="btn btn-xs btn-info">Back</label></a> 
                        </div>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            
                            <div class="col-sm-6">
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Hrs/Week</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input id="hrs" type="text" class="form-control" placeholder="Hours/Week" name="hrs" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['hrs']."'"; } ?> required />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Rate/Hr</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input  id="rate" type="text" class="form-control" placeholder="Hourly Rate" name="rate" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['rate']."'"; } ?> required />
                                </div>
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Rate/Month</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <input  id="monthly" type="text" class="form-control" placeholder="Monthly Rate" name="monthly" <?php if(isset($_GET['id'])){ echo "value='".$rvalue['monthly']."'"; } ?> required />
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Date From</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <div class="input-group date">
                                      <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                      </div>
                                      <input required type="text" class="form-control pull-right" name="datefrom" id="datepicker" <?php if(isset($_GET['id'])){ echo "value='".date("m/d/Y",strtotime($rvalue['datefrom']))."'"; } ?>>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group" style="margin-bottom: 0px; ">
                                    <label>Date To</label> <label><input  type="checkbox" id="present" name="present" style="margin-top: 10px; margin-left: 5px; margin-right: 3px;">Up to Present</label>
                                    <!-- <span class="input-group-addon"><i class="fa fa-envelope"></i></span> -->
                                    <div class="input-group date">
                                      <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                      </div>
                                      <input type="text" required class="form-control pull-right dt2" name="dateto" id="datepicker2" <?php if(isset($_GET['id'])){ echo "value='".date("m/d/Y",strtotime($rvalue['dateto']))."'"; } ?>>
                                    </div>
                                </div>
                            </div>    
                            
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="btn_save" class="btn btn-success fa fa-plus-square btn-sm" value="<?php echo $action; ?>">
                    </div>
                </div>
            </form>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->


<script>


function calculate(param){
    var hrs = $("#hrs").val();
    var rate = $("#rate").val();
    var monthly = $("#monthly").val();
    var employee_type = $('#employee_type').val();
    if(param=="monthly"){
        //$('#rate').attr('readonly', 'true');
        //$('#rate').val(0);
        //$('#monthly').removeAttr('readonly');
        if(hrs=="" || hrs==0){
            
            alert("Please enter number of hours first!");
            $("#hrs").focus();
        }else{
            rate = (monthly/4) / hrs;
            $("#rate").val(rate);
        }
    }else{
        //$('#monthly').attr('readonly', 'true');
        //$('#monthly').val(0);
        //$('#rate').removeAttr('readonly');
        if(hrs=="" || hrs==0){
            alert("Please enter number of hours first!");
            $("#hrs").focus();
        }else{
            monthly = (rate * hrs) * 4;
            $("#monthly").val(monthly);
        }
    }
    
}

$("#present").on("click", function(){
    var st = $( "#present" ).is( ":checked" );
    if(st==true){
        $(".dt2").attr("readonly","true");
        $(".dt2").attr("id","dt2");
        $(".dt2").removeAttr("required");
    }else{
        $(".dt2").removeAttr("readonly");
        $(".dt2").attr("id","datepicker2");
        $(".dt2").attr("required","");
    }
});

$("#department_id").on("change", function(e){
        var did = $(this).val();
        var options = "";

        $('#subdepartment_id')
            .find('option')
            .remove()
            .end()
            .append('<option>--SELECT--</option>')
            //.val('whatever')
        ;
        
        <?php foreach ($sdpt as $key => $value) {  ?>  

            if(did==<?php echo $value['department_id']; ?>){ 

                options = options + "<option value='<?php echo $value['id']; ?>'><?php echo $value['name']; ?></option>";

            }
            

        <?php } ?>
        //console.log(options);
        $("#subdepartment_id").append(options);
});

<?php if(isset($_GET['id'])): ?>
function setDefault(){
        var did = $("#department_id").val();
        var options = "";

        $('#subdepartment_id')
            .find('option')
            .remove()
            .end()
            .append('<option>--SELECT--</option>')
            //.val('whatever')
        ;
        
        <?php foreach ($sdpt as $key => $value) {  if($_GET['sid']==$value['id']){ $s="selected"; }else{ $s=""; } ?>  

            if(did==<?php echo $value['department_id']; ?>){ 

                options = options + "<option value='<?php echo $value['id']; ?>' <?php echo $s; ?>><?php echo $value['name']; ?></option>";

            }
            

        <?php }  ?>
        console.log(options);
        $("#subdepartment_id").append(options);
    }
    setDefault();
<?php endif; ?>


$('#fname').on('change',function(e){
    var un = $(this).val();
    <?php if(!isset($_GET['id'])): ?>
        var ext = makeUser();
        var pass = makeRandom();
        un = un.substring(0,3) + ext;
        $("#un").val(un);
        $("#pw").val(pass);
    <?php endif; ?>

});
$('#rate').on('input',function(e){
    calculate("rate");
});
$('#monthly').on('input',function(e){
    calculate("monthly");
});
$('#hrs').on('input',function(e){
    calculate("hrs");
});
$('#employee_type').on('change',function(e){
    var employee_type = $(this).val();
    var param = "monthly";
    //alert(employee_type);
    if(employee_type==0){
        $('#rate').val(0);
        param = "monthly";
    }else{
        $('#monthly').val(0);
        param = "rate";
    }
    calculate(param);
});

</script>