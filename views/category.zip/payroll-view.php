
<script>


    function deleteThis(id){
        if (confirm('Are you sure you want to delete this?')) {
            window.location.href = window.location.href + '&del='+id;
        }
    }

    function setGetParameter(paramName, paramValue)
    {
        var url = window.location.href;
        var hash = location.hash;
        url = url.replace(hash, '');
        if (url.indexOf(paramName + "=") >= 0)
        {
            var prefix = url.substring(0, url.indexOf(paramName));
            var suffix = url.substring(url.indexOf(paramName));
            suffix = suffix.substring(suffix.indexOf("=") + 1);
            suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix.indexOf("&")) : "";
            url = prefix + paramName + "=" + paramValue + suffix;
        }
        else
        {
            if (url.indexOf("?") < 0)
                url += "?" + paramName + "=" + paramValue;
            else
                url += "&" + paramName + "=" + paramValue;
        }
        window.location.href = url + hash;
    }

    function reloadWithStatus(val){
        setGetParameter('istatus', val);
    }

</script>

<?php
$response['message']="";

if(isset($_GET['st'])){
    $udata = array("model"=>"payroll", "values"=>"status = '".$_GET['st']."'", "condition"=>" WHERE id = '".$_GET['id']."'");
    $upn = $app->update2($udata);
}


$data = array("model"=>"payroll", "condition"=>" WHERE id = '".$_GET['id']."'");
$payroll=$app->getRecord2($data);
$payroll = $payroll['data'][0];
//$eawards = json_decode($payroll['employee_id']);
$emps = $app->getEmployees();

$ps = $app->getPayrollStatus();


$inclusives = $app->getInclusives($payroll['id']);

 $tp=0;
 $t_incentives = 0;
 $t_deductions = 0;
 foreach($inclusives as $ke => $value){
     //echo json_encode($value);
    $tp = $tp + $value['total'];
    $t_incentives = $t_incentives+$value['incentives'];
    $t_deductions = $t_deductions +$value['deductions'];
 }
 
 $net_salaries = ($tp - $t_incentives)-$t_deductions;


//echo json_encode($inclusives);
//exit();
?>

<?php
$color = "#000";

if($payroll['status']==0){ $bg = "bg-yellow"; }
else{  $bg = "bg-green";  }


?>

<section class="invoice">
    <!-- title row -->
    <div class="row">
        <div class="col-xs-12">
            <h2 class="page-header" style="color: <?php echo $color; ?>">
                <i class="fa fa-globe"></i>
                <?php
                 echo date("M jS, Y", strtotime($payroll['datefrom']))."-".date("M jS, Y", strtotime($payroll['dateto']))." (Payroll View)";
                ?>
                <small class="pull-right">Date: <?php echo date("Y")."-".date("m")."-".date("d"); ?></small>
                
            </h2>
            <div class="pull-right" style="margin-top: -75px;">
                            <a href="?page=payroll"><label class="btn btn-xs btn-info">Back</label></a> 
                        </div>
        </div>
        <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
        <div class="col-sm-6 invoice-col">
          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
                <tbody>
                <tr>
                  <th>Payroll Code</th>
                  <td><span class="badge bg-light-blue"><?php echo $payroll['payroll_code']; ?></span></td>
                </tr>
                <tr>
                  <th>Inclusive Dates</th>
                  <td><span class="badge bg-light-blue"> <?php
                 echo date("M jS, Y", strtotime($payroll['datefrom']))."-".date("M jS, Y", strtotime($payroll['dateto'])); ?></span></td>
                </tr>
                <tr>
                  <th>Total Salaries</th>
                  <td><span class="badge bg-light-blue"><?php echo number_format($net_salaries,2); ?></span></td>
                </tr>
                <tr>
                  <th>Total Incentives/Allowances</th>
                  <td><span class="badge bg-light-blue"><?php echo number_format($t_incentives,2); ?></span></td>
                </tr>
                <tr>
                  <th>Total Deductions</th>
                  <td><span class="badge bg-light-blue"><?php echo number_format($t_deductions,2); ?></span></td>
                </tr>
                <tr>
                  <th>Computed Total Payroll Amount</th>
                  <td><span class="badge bg-light-blue"><?php echo number_format($tp,2); ?></span></td>
                </tr>
                
                <tr>
                <th>Status</th>
                  <td>
                  <select class="form-control select2 select2-hidden-accessible <?php echo $bg; ?> input-sm" id="alterme" name="alterme" style="width: 100%; height: 15px;" tabindex="-1" aria-hidden="true">
                        <?php 
                        foreach ($ps as $pkk => $pvv) {
                            if($pkk==$payroll['status']){ $ppss="selected"; }else{ $ppss=""; }
                            echo "<option value='$pkk' $ppss>$pvv</option>";
                        }

                        ?>
                                
                                 
                                </select> 
                 </td>
                </tr>
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col -->
        <div class="col-sm-6 invoice-col">
            <address>

            </address>
        </div>
        
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->




<?php

if(isset($_GET['del'])){

    $data = array('model'=>'issues', 'condition'=>" WHERE id = '".$_GET['del']."'");
    $response = $app->delete2($data);
}





?>




    <br>

    <div class="row">

        <div class="col-md-12">

            <!-- Button trigger modal -->



            <br>
            <div class="widget-content ">
                <div>

                <?php if( $response['message']=="Successful"){
                    echo '<br><div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">x</a>
                    <strong>Success!</strong> Record '.$daction.' successfully.
                </div>';
                }
                ?>



            </div>
            <div class="box" style="border-top:none; box-shadow:none; min-height: 20px; margin-top: 0px; margin-bottom: 10px;">
                 <?php if($_SESSION['acl']['employee-view']==1): ?>    
                                        <a class="pull-right" style="margin-bottom: 5px;"href="?page=payslip-create&id=<?php echo $_GET['id']; ?>">
                                            <label  class="btn btn-info btn-xs"><i class="fa fa-file-text-o"></i>
                                            Add Employee Payslip
                                            </label>
                                        </a>
                                    <?php endif; ?>
            </div>
            
            <div id="print" class="myDivToPrint">

                <div class="box">
                         
      
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th style="width:auto;"></th>
                                <th >Name</th>
                                <th >Position</th>
                                <th >Monthly</th>
                                <th >Bi-Monthly</th>
                                <th >Allowance</th>
                                <th >Deduction</th>
                                <th >Net</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $n=0;
                            foreach($inclusives as $ke => $value): $n++;

                           //echo json_encode($value)."<br>";
                            $did = $emps[$value['employee_id']]['department_id'];

                            ?>
                                <tr>
                                    <td ><?php echo $n; ?></td>
                                    <td ><?php echo $emps[$value['employee_id']]['lname'].", ".$emps[$value['employee_id']]['fname']; ?></td>
                                    <td ><?php echo $emps[$value['employee_id']]['position']; ?></td>
                                    <td ><?php echo number_format($value['monthly'],2); ?></td>
                                    <td ><?php echo number_format($value['monthly']/2,2); ?></td>
                                    <td><?php echo number_format($value['incentives'],2); ?></td>
                                    <td><?php echo number_format($value['deduction'],2); ?></td>
                                    <td><?php echo number_format($value['total'],2); ?></td>
                                    <td>

                                    <?php if($_SESSION['acl']['payroll-view']==1): ?>    
                                        <a href="?page=payslip-create&id=<?php echo $_GET['id']; ?>&pid=<?php echo $value['id']; ?>&did=<?php echo $did; ?>&eid=<?php echo $value['employee_id']; ?>">
                                            <button  class="btn btn-warning btn-xs"><i class="fa fa-file-text-o"></i> Update</button>
                                        </a>
                                    <?php endif; ?>
                                    <?php if($_SESSION['acl']['payroll-view']==1): ?>    
                                        <a href="?page=payslip-view&id=<?php echo $_GET['id']; ?>&pid=<?php echo $value['id']; ?>&did=<?php echo $did; ?>&eid=<?php echo $value['employee_id']; ?>">
                                            <button  class="btn btn-info btn-xs"><i class="fa fa-file-text-o"></i> View</button>
                                        </a>
                                    <?php endif; ?>

                                   
                                        

                                    </td>
                                </tr>
                            <?php endforeach; ?>

                            </tbody>
                            <tfoot>
                            <tr>
                                <th style="width:auto;"></th>
                                <th >Name</th>
                                <th >Position</th>
                                <th >Monthly</th>
                                <th >Bi-Monthly</th>
                                <th >Allowance</th>
                                <th >Deduction</th>
                                <th >Net</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>    
                    <!-- /.box-body -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /.content -->

<script>
$("#alterme").on("change", function(){
    var status = $(this).val();
    location.href = "index.php?page=payroll-view&id=<?php echo $_GET['id']; ?>&st="+status;
});
</script>